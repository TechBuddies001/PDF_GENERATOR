package com.example.sampletest.interfaces

interface LanguageChangeListener {
    fun onLanguageChanged(lang: Int)
}