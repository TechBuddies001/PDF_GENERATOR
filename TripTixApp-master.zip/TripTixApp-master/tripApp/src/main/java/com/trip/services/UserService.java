package com.trip.services;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.trip.models.UserRoles;
import com.trip.models.Users;

import com.trip.repo.UserRepo;
import com.trip.repo.UserRolesRepo;
import com.trip.requset.CustomResponse;
import com.trip.requset.UserDTO;
import com.trip.response.Countuser;
import com.trip.response.UserDetaileResponse;
import com.trip.response.UserResponse;

@Service
public class UserService {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRepo userRepository;

	@Autowired
	UserRolesRepo rolesRepo;

	@Autowired
	private GenPassEmail emailService;

	@Autowired
	ObjectMapper mapper;

	// ADMIN METHODS

	@Transactional(readOnly = true)
	public ResponseEntity<CustomResponse> findUsersByPage(int page, int size) {

		Pageable pageRequest = PageRequest.of(page, size, Sort.by("id").descending());
		CustomResponse response = new CustomResponse();
		List<UserDetaileResponse> res = new ArrayList<UserDetaileResponse>();
		try {
			// Page<Users> users = userRepository.findAll(pageRequest);
			Page<Users> users = userRepository.findAllUsersByPage(pageRequest);
			if(users != null) {
				for(int i=0;i<users.getContent().size();i++) {
					UserDetaileResponse r = new UserDetaileResponse();
					r.setUserId(users.getContent().get(i).getId());
					r.setName(users.getContent().get(i).getName());
					r.setFirstname(users.getContent().get(i).getFirstname());
					r.setLastName(users.getContent().get(i).getLastName());
					r.setEmail(users.getContent().get(i).getEmail());
					r.setMobileNo(users.getContent().get(i).getMobileNo());
					r.setCity(users.getContent().get(i).getCity());
					r.setAddress(users.getContent().get(i).getAddress());
					r.setPinCode(users.getContent().get(i).getPinCode());
					r.setState(users.getContent().get(i).getState());
					r.setPhotoUrl(users.getContent().get(i).getPhotoUrl());
					r.setActive(users.getContent().get(i).isActive());
					r.setUserRollid(users.getContent().get(i).getUserRollid());
					r.setStatus(users.getContent().get(i).getStatus());
					res.add(r);
				}
				response.setMessage("Success");
				response.setStatus(true);

				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);

			}else {
				response.setMessage("Error");
				response.setStatus(false);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}
			
		} catch (Exception e) {
			response.setMessage("Error");
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		
	}

	public ResponseEntity<CustomResponse> searchUsers(String key) {
		CustomResponse response = new CustomResponse();
		try {

//			Users u = null ;
//			int i =  u.getUserRole().getRole_id();

			List<Users> users = userRepository.searchUserBykeyword(key);
			response.setMessage("Success");
			response.setStatus(true);
			HashMap<String, List<Users>> map = new HashMap<String, List<Users>>();

			map.put("content", users);
			response.setResponseObj(map);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error");
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	private Date getLastWeekDate() {
		// TODO Auto-generated method stub
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -7);
		return cal.getTime();
	}

	public ResponseEntity<CustomResponse> getAllUsers() {
		CustomResponse response = new CustomResponse();
		List<UserDetaileResponse> res = new ArrayList<UserDetaileResponse>();
		try {
			List<Users> users = (List<Users>) userRepository.findAllUsers();
		if(users != null) {
			for(int i=0;i<users.size();i++) {
				UserDetaileResponse r = new UserDetaileResponse();
				r.setUserId(users.get(i).getId());
				r.setName(users.get(i).getName());
				r.setFirstname(users.get(i).getFirstname());
				r.setLastName(users.get(i).getLastName());
				r.setEmail(users.get(i).getEmail());
				r.setMobileNo(users.get(i).getMobileNo());
				r.setCity(users.get(i).getCity());
				r.setAddress(users.get(i).getAddress());
				r.setPinCode(users.get(i).getPinCode());
				r.setState(users.get(i).getState());
				r.setPhotoUrl(users.get(i).getPhotoUrl());
				r.setActive(users.get(i).isActive());
				r.setUserRollid(users.get(i).getUserRollid());
				r.setStatus(users.get(i).getStatus());
				res.add(r);
			}
			response.setMessage("Success");
			response.setStatus(true);

			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		}else {
			response.setMessage("Error");
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

		} catch (Exception e) {
			response.setMessage("Error");
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	// USER METHODS

	public Users findByName(String email) {
		return userRepository.findByEmailIgnoreCase(email);

	}

	public ResponseEntity<CustomResponse> addUser(Users user) {
		UserRoles roles = new UserRoles();
		CustomResponse response = new CustomResponse();
		UserResponse userdetails = new UserResponse();
		if (userRepository.existsByEmail(user.getEmail())) {

			response.setMessage("email registerd please use other email");

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		try {

			if (!isValid(user.getEmail())) {
				response.setMessage("Invalid Email");
				response.setStatus(true);
				response.setStatusCode(400);
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
			}

			// String newPassword=randomPassword();
			String newPassword = user.getPassword();
			user.setPassword(bCryptPasswordEncoder.encode(newPassword));
			// user.setPassword(newPassword);
			if (userRepository.save(user) != null) {
				Users userid = userRepository.save(user);
				int id = userid.getId();
				Optional<Users> userrole = userRepository.findById(id);
				if (userrole.isPresent() == true) {
					
					roles.setRole_id(id);
					roles.setTitle("User");
					rolesRepo.save(roles);
				}
				
				Optional<UserRoles> role = rolesRepo.findById(user.getId());
				if (role.isPresent() == true) {
					userdetails.setRollAs(role.get().getTitle());
				}
				userdetails.setUserId(user.getId());
				userdetails.setName(user.getName());
				userdetails.setEmail(user.getEmail());
				userdetails.setActive(user.isActive());
				userdetails.setPhotoUrl(user.getPhotoUrl());
				emailService.sendWelcomeMail(user.getEmail(), newPassword);
				response.setMessage("Verification email sent with login details...");
				response.setStatus(true);
				//response.setMessage("Success");
				response.setStatusCode(200);
				response.setStatus(true);
				ObjectNode object = mapper.createObjectNode();
				// object.put("token", jwtTokenUtil.generateToken(user.getEmail()));
				object.putPOJO("User", userdetails);
				response.setResponseObj(object);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response.setMessage("Some error occured");
				response.setStatus(false);
			}
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error :" + e.getLocalizedMessage());
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}

	}

	static boolean isValid(String email) {
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}

	// addMultipleUsers

	public List<Users> addMultipleUsers(List<Users> users) {

		for (int i = 0; i < users.size(); i++) {
//			Department department = deptRepo.getOne(users.get(i).getDeptId());
//			users.get(i).setDepartment(department);
		}

		return (List<Users>) userRepository.saveAll(users);

	}

	public ResponseEntity<CustomResponse> updateActiveToInActiveState(int id) {
		// System.out.println(user);
		Users userObj = null;

		CustomResponse response = new CustomResponse();
		try {
			if (userRepository.existsById(id)) {

				userObj = userRepository.findById(id).orElse(null);
				if (userObj.isActive())
					userObj.setActive(false);
				else
					userObj.setActive(true);

				response.setMessage("Success");
				response.setStatus(true);
				userRepository.save(userObj);
				// response.setResponseObj();

			} else {
				response.setMessage("User doesn't exist");
				response.setStatus(false);
				System.out.println("User doesn't exist");
			}

			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error");
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

	public ResponseEntity<CustomResponse> delete(@PathVariable int id) {

		CustomResponse response = new CustomResponse();
		try {
			userRepository.deleteById(id);
			rolesRepo.deleteById(id);
			response.setMessage("User deleted Successfully");
			response.setStatus(true);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error :" + e.getLocalizedMessage());
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
	}

	// ABCDEFGHIJKLMNOPQRSTUVWXYZ
	private static final String NUMERIC_STRING = "0123456789";

	public static String randomPassword() {
		int count = 4;
		StringBuilder builder = new StringBuilder();

		while (count-- != 0) {
			int character = (int) (Math.random() * NUMERIC_STRING.length());
			builder.append(NUMERIC_STRING.charAt(character));
		}

		return builder.toString();
	}

	public Users getUser(String email) {
		try {
			return userRepository.findByEmailIgnoreCase(email);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}

	}

	public ResponseEntity<CustomResponse> updateuserProfile(UserDTO user) {
		CustomResponse response = new CustomResponse();
		UserResponse userRes = new UserResponse();
		//Users userdetail = new Users();
		int id = user.getUserId();
		Optional<Users> userpersent = userRepository.findById(id);
		if(userpersent.isPresent()==true) {
			
			userpersent.get().setFirstname(user.getFirstname());
			userpersent.get().setLastName(user.getLastName());
			userpersent.get().setAddress(user.getAddress());
			userpersent.get().setCity(user.getCity());
			userpersent.get().setState(user.getState());
			userpersent.get().setMobileNo(user.getMobileNo());
			userpersent.get().setPinCode(user.getPinCode());
			Users ures =userRepository.save(userpersent.get());
			response.setMessage("profile update Success");
			response.setStatus(true);
			response.setResponseObj(ures);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		}else {
			response.setMessage("Error user not persent");
			response.setStatus(false);
			response.setStatusCode(400);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		
	}

	public boolean restpassword(String email) {
		CustomResponse response = new CustomResponse();
		boolean returnvalue =false;
		//Users user = userRepository.findByEmailIgnoreCase(email);
		Optional<Users> optional = userRepository.findByEmail(email);
		if (!optional.isPresent()) {
			response.setMessage("Error user not persent");
			response.setStatus(false);
			response.setStatusCode(400);
			return returnvalue;
		}else {
			
			Users user = optional.get();
			//String token =Utils.generatepasswordresetetoken(user.getId());
			user.setResetToken(UUID.randomUUID().toString());
			userRepository.save(user);
			return returnvalue;
		}
		
//		if(user == null) {
//		return returnvalue;
//		}
//		return returnvalue;
	}

	public ResponseEntity<CustomResponse> countUser() {
		CustomResponse response = new CustomResponse();
		Countuser count = new Countuser();
		//List<Users>user =userRepository.findAllActiveUsers();
		int alluser = userRepository.findAllUserCount();
		int allactiveuser =userRepository.findAllActiveUserCount();
		int allInactiveuser =userRepository.countAllInActiveUser();
		count.setActiveUsers(allactiveuser);
		count.setTotalUsers(alluser);
		count.setInactiveUsers(allInactiveuser);
		response.setMessage("All Active and InActive users");
		response.setStatus(true);
		response.setResponseObj(count);
		return ResponseEntity.status(HttpStatus.OK).body(response);
		
		
	}

	public ResponseEntity<CustomResponse> updateIActiveToActiveState(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
