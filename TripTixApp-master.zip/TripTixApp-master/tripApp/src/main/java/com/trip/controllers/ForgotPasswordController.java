package com.trip.controllers;

import java.util.Optional;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.requset.ChangepassRequest;
import com.trip.requset.CustomResponse;
import com.trip.requset.LoginCred;
import com.trip.requset.ResetPassRequestResponse;
import com.trip.response.PasswordResponse;
import com.trip.response.UserResponse;
import com.trip.services.GenPassEmail;
import com.trip.services.UserService;

@RestController

@RequestMapping(path = "/password")
public class ForgotPasswordController {

	@Autowired
	UserRepo userreposiotory;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
  
	
	@Autowired
	private UserService service;
	
	@Autowired
	private GenPassEmail emailService;
	
	@GetMapping(path = "/recoverPass")
	public ResponseEntity<CustomResponse> getpass(@RequestParam String email) {

		CustomResponse response = new CustomResponse();
		PasswordResponse pass = new PasswordResponse();
		Users user = userreposiotory.findByEmailIgnoreCase(email);
		if (user != null) {
			pass.setUserId(user.getId());
			pass.setEmail(user.getEmail());
			pass.setPassword(user.getPassword());
			response.setMessage("Success");
			response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(pass);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} else {
			response.setMessage("Error : This Email not persent in databases");
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}
	


	// Process form submission from forgotPassword page
			@RequestMapping(value = "/forgot", method = RequestMethod.POST)
			public ResponseEntity<CustomResponse>  processForgotPassword( @RequestParam("email") String userEmail, HttpServletRequest request) {
				CustomResponse response = new CustomResponse();
				// Lookup user in database by e-mail
				Optional<Users> optional = userreposiotory.findByEmail(userEmail);
				if (!optional.isPresent()) {
					response.setMessage("Error user not persent");
					response.setStatus(false);
					response.setStatusCode(400);
					return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
				} else {
					
					
					String otpSting  = generateOTP();
					Users user = optional.get();
					user.setResetToken(UUID.randomUUID().toString());   
					user.setPassword(bCryptPasswordEncoder.encode(otpSting));
					userreposiotory.save(user);
					String appUrl = request.getScheme() + "://" + request.getServerName();
					
					// Email message
					SimpleMailMessage passwordResetEmail = new SimpleMailMessage();
					passwordResetEmail.setFrom("op28011994@gmail.com");
					passwordResetEmail.setTo(user.getEmail());
					passwordResetEmail.setSubject("Password Reset Request");
					passwordResetEmail.setText("YOUR New PASSWORD IS  "+otpSting);
//					passwordResetEmail.setText("To reset your password, click the link below:\n" + appUrl
//							+ "/reset?token=" + user.getResetToken());
				//	passwordResetEmail.setText("To complete the password reset process, please click here: "
				 //             + "http://localhost:8080/password/confirm-reset?token="+user.getResetToken());
					emailService.sendEmail(passwordResetEmail);

					// Add success message to view
					response.setMessage("your new password send your email");
					response.setStatusCode(200);
					response.setStatus(true);
					response.setResponseObj(user);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}

				
			}
			
			 private String generateOTP() {
				 int randomPin   =(int) (Math.random()*90000)+10000; 
			        String otp  = String.valueOf(randomPin); 
			        return otp; 
	}



			@RequestMapping(value="/confirm-reset", method= RequestMethod.GET)
			 public ResponseEntity<CustomResponse>  validateResetToken(@RequestParam("token")String confirmationToken) {
				 CustomResponse response = new CustomResponse(); 
				 Optional<Users> token = userreposiotory.findByResetToken(confirmationToken);
                    System.out.println(" token ----  "+token.get().getResetToken());
			        if (token.isPresent()==true || token.get().getResetToken()== confirmationToken) {
			        	Optional<Users> user = userreposiotory.findByEmail(token.get().getEmail());
			           if(user.isPresent()==true) {
			        	   user.get().setStatus("Active");
			              userreposiotory.save(user.get());
			  
			           }
			           response.setMessage("token verified successfully");
						response.setStatusCode(200);
						response.setStatus(true);
						//response.setResponseObj(user);
						 return ResponseEntity.status(HttpStatus.OK).body(response);
			        } else {
			        	response.setMessage("token not persent in database ");
						response.setStatus(false);
						response.setStatusCode(500);
						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			        }
			       
			    }
			 
			 @RequestMapping(value = "/change-password", method = RequestMethod.POST)
			 public ResponseEntity<CustomResponse> resetUserPassword(@RequestBody ResetPassRequestResponse user) {
				 CustomResponse response = new CustomResponse();
			        if (user.getEmail() != null) {
			            // Use email to find user
			        	
			            Users tokenUser = userreposiotory.findByEmailIgnoreCase(user.getEmail());
			            if(tokenUser != null) {
			            tokenUser.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
			            userreposiotory.save(tokenUser);
			            response.setMessage("password updated");
						response.setStatusCode(200);
						response.setStatus(true);
						response.setResponseObj(user);
						
			            }
			        else {
			        	response.setMessage("user is  not Persent");
						response.setStatus(false);
						response.setStatusCode(500);
						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
			        }
			        
			    }
			        return ResponseEntity.status(HttpStatus.OK).body(response);
			 }
			 
			 @RequestMapping(value = "/resetold-password", method = RequestMethod.POST)
			 public ResponseEntity<CustomResponse> changeUserPassword(@RequestBody ChangepassRequest user) {
				 CustomResponse response = new CustomResponse();
//				String newpass = user.getNewPassword();
//				
//				if(newpass.isBlank()||newpass.length()==0||newpass=="") {
//				    response.setMessage("plese enter a valid password");
//					response.setStatusCode(200);
//					response.setStatus(true);
//			}
				 Users usersdetail = userreposiotory.findByEmailIgnoreCase(user.getEmail());
				
				 
				 String passswd = "";
				 if(usersdetail!=null) {
					 passswd = usersdetail.getPassword();
						
					 if(bCryptPasswordEncoder.matches(user.getOldPassword(), passswd)) {
						 usersdetail.setPassword(bCryptPasswordEncoder.encode(user.getNewPassword()));
				            userreposiotory.save(usersdetail);
				            response.setMessage("password updated");
							response.setStatusCode(200);
							response.setStatus(true);
							response.setResponseObj(user);
					 }else{
						 response.setMessage("old password not match");
							response.setStatusCode(200);
							response.setStatus(false);
							response.setResponseObj(user);
					 }
				 }else {
					 response.setMessage("user is  not Persent");
						response.setStatus(false);
						response.setStatusCode(500);
						return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
				 }
				 return ResponseEntity.status(HttpStatus.OK).body(response);
			 }
}


