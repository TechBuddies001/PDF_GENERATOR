package com.trip.requset;

import javax.validation.constraints.NotNull;

public class PaymentRequest {
	
	@NotNull
	private int userId;
	
	private String Amount;
	private String StripePaymentId;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getAmount() {
		return Amount;
	}
	public void setAmount(String amount) {
		Amount = amount;
	}
	public String getStripePaymentId() {
		return StripePaymentId;
	}
	public void setStripePaymentId(String stripePaymentId) {
		StripePaymentId = stripePaymentId;
	}
	

}
