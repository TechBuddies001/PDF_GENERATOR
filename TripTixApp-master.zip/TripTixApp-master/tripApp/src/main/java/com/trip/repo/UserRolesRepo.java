package com.trip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.trip.models.UserRoles;

@RepositoryRestResource
//@RestResource(exported = false)
public interface UserRolesRepo extends JpaRepository<UserRoles, Integer> {
	
	
	public UserRoles findByTitleIgnoreCase(String role);
//	@Query(value="SELECT Count(*) FROM Event WHERE organised_by_id = ?1", nativeQuery = true)
//	public int findTotalEventsByArtist(int artistId);

}
