package com.trip.controllers;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.annotations.SerializedName;
import com.stripe.Stripe;

import com.stripe.exception.AuthenticationException;
import com.stripe.exception.CardException;
import com.stripe.exception.InvalidRequestException;
import com.stripe.exception.StripeException;
import com.stripe.model.Card;
import com.stripe.model.Customer;
import com.stripe.model.ExternalAccountCollection;
import com.stripe.model.PaymentIntent;
import com.stripe.model.Token;
import com.stripe.param.CustomerCreateParams;
import com.stripe.param.PaymentIntentCreateParams;
import com.trip.models.TicketSubscriptionPayment;
import com.trip.models.Users;
import com.trip.repo.TicketPaymentRepository;
import com.trip.repo.UserRepo;
import com.trip.requset.CardDetail;
import com.trip.requset.ChargeRequest;
import com.trip.requset.CustomResponse;
import com.trip.requset.PaymentRequest;
import com.trip.requset.SubscriptionRequest;
import com.trip.requset.UseraddStripeRequest;

import io.github.cdimascio.dotenv.Dotenv;

import org.springframework.ui.Model;
@RestController
@RequestMapping("/payment")
@JsonAutoDetect(fieldVisibility = Visibility.DEFAULT)
public class PaymentController {
	
	 static class CreatePaymentResponse {
	        private String publicKey;
	        private String clientSecret;
	        private String id;

	        public CreatePaymentResponse() {
				super();
			}

			public CreatePaymentResponse(String publicKey, String clientSecret, String id) {
	            this.publicKey = publicKey;
	            this.clientSecret = clientSecret;
	            this.id = id;
	        }
	    }
	
	
	@Autowired
	private UserRepo userRepository;
	
	@Autowired
	private TicketPaymentRepository subscriptionrepo;
	
	@PostMapping("/addpaymentDetail")
	public ResponseEntity<CustomResponse>  addPaymentDetail(@RequestBody PaymentRequest stripe) throws AuthenticationException, InvalidRequestException, CardException {
		CustomResponse response = new CustomResponse();
		try {
			Users userpayment = new Users();
			Optional<Users> user = userRepository.findById(stripe.getUserId());
			if(user.isPresent()== true) {
				user.get().setAmount(stripe.getAmount());
				user.get().setStripepaymentId(stripe.getStripePaymentId());
				userRepository.save(user.get());
				response.setMessage("User Payment Success ");
				response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(stripe);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}else {
				response.setMessage("user not found ");
				response.setStatusCode(200);
				response.setStatus(false);
				response.setResponseObj(null);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		}catch(Exception e){
			e.printStackTrace();
			response.setMessage("internal server error ");
			response.setStatusCode(500);
			response.setStatus(false);
			response.setResponseObj(e);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}	
	
		
		
	}
	
//	@PostMapping("/addcardDetail")
//	public ResponseEntity<CustomResponse>  addCardrOnStripe(@RequestBody CardDetail card) throws AuthenticationException, InvalidRequestException, APIConnectionException, CardException, APIException {
//		CustomResponse response = new CustomResponse();
//		UsersPaymentDetails payment = new UsersPaymentDetails();
//		Stripe.apiKey = "sk_test_51HTrWTGk9TWJsMqYjqWngVpPrjq9OLaaRTrzRHb77sPraJhTlyIuAbtKaY7pq2lD6zGn3MxsPNzpUXV7XZRHR7Zt0015UfbtGk";
//		Gson gson = new GsonBuilder().setPrettyPrinting().create();
//		Customer newCustomer = Customer.retrieve("cus_IBpF0LPI64nxvt");
//		//Customer a = Customer.retrieve(card.getCusId());
//		Map<String,Object> cardParam = new HashMap<String, Object>();
//		cardParam.put("number", card.getCardNumber());
//		cardParam.put("exp_month", card.getExpMonth());
//		cardParam.put("exp_year", card.getExpYear());
//		cardParam.put("cvc", card.getCvc());
//		
//		Map<String,Object> cardToken = new HashMap<String, Object>();
//		cardToken.put("card", cardParam);
//		
//		Token token = Token.create(cardToken);
//		System.out.println(token);
//		
//		Map<String,Object> source = new HashMap<String, Object>();
//		source.put("source", token.getId());
//		
//		System.out.println(source);
//		newCustomer.getSources().create(source);
//		
//		//change customer id
//        
//		response.setMessage("Cedit/debit card is added on Stripe ");
//		response.setStatusCode(200);
//		response.setStatus(true);
//		response.setResponseObj(newCustomer);
//		return ResponseEntity.status(HttpStatus.OK).body(response);
//
//}
	@PostMapping("/create-payment-intent")
	public String  paymentOnStripe(@RequestBody ChargeRequest charge) throws StripeException{
		// throws AuthenticationException, InvalidRequestException, APIConnectionException, CardException, APIException {
		CustomResponse response = new CustomResponse();
	
		Stripe.apiKey = "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";

	      PaymentIntentCreateParams createParams = new PaymentIntentCreateParams.Builder()
	      .setCurrency("usd")
	      .setAmount((long) charge.getAmount()*100)
	     
	      .build();
	      // Create a PaymentIntent with the order amount and currency
	      PaymentIntent intent = PaymentIntent.create(createParams);
	      CreatePaymentResponse paymentResponse = new CreatePaymentResponse();
	     
	    
			return  gson.toJson(intent);
		

}
	
	@PostMapping("/addsubscriptionDetail")
	public ResponseEntity<CustomResponse>  addSubsrciption(@RequestBody SubscriptionRequest subscription)
{
		CustomResponse response = new CustomResponse();
		String monthly = null;
		try {
			
			TicketSubscriptionPayment subpay = new TicketSubscriptionPayment();
		    subpay.setAmount(subscription.getAmount());
		    subpay.setSubscriptionType(subscription.getSubscriptionType());
		    subpay.setStripepaymentId(subscription.getStripepaymentId());
		    subpay.setUserId(subscription.getUserId());
		    Calendar cal = Calendar.getInstance();
		    SimpleDateFormat dateOnly = new SimpleDateFormat("dd/MM/yyyy");
		    System.out.println(""+dateOnly.format(cal.getTime()));
		    
		    String subsDate =dateOnly.format(cal.getTime());
		    
		    
		    subpay.setSubsDate(dateOnly.format(cal.getTime()));
		    //=================total ticket subscription================//
		    
		    int amount=Integer.parseInt(subscription.getAmount()); 
		    
		    String subscriptionType  = subscription.getSubscriptionType();
		    
		   
		    	
		    if(amount == 30)
		    {
		    	subpay.setTotalTicket(200);
		    }
		    if(amount == 60) 
		    {
		    	subpay.setTotalTicket(500);
		    }
		    if(amount == 100)
		    {
		    	subpay.setTotalTicket(1000);
		    }
		    //============Expire subscription===================//
		    
		    
		    String oldDate =  subsDate;
			
			System.out.println("Date before Addition: "+oldDate);
			//Specifying date format that matches the given date
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			Calendar c = Calendar.getInstance();
			
			   //Setting the date to the given date
			   c.setTime(sdf.parse(oldDate));
			
			   
			//Number of Days to add
			c.add(Calendar.DAY_OF_MONTH, 30);  
			//Date after adding the days to the given date
			String newDate = sdf.format(c.getTime());  
			
			//Displaying the new Date after addition of Days
			System.out.println("Date after Addition: "+newDate);
			//subsDetails.setSubExpaireDate(newDate);
			   
		    //===========================================================//
		    TicketSubscriptionPayment paydetail = subscriptionrepo.save(subpay);
		    
		    if(paydetail!=null) {
		    	Optional<Users> user = userRepository.findById(subscription.getUserId());
		    	if(user.isPresent()== true) {
					user.get().setAmount(paydetail.getAmount());
					user.get().setSubsType(paydetail.getSubscriptionType());
					user.get().setStripepaymentId(paydetail.getStripepaymentId());
					user.get().setSubsDate(dateOnly.format(cal.getTime()));
					user.get().setTotalTicket(paydetail.getTotalTicket());
				    user.get().setTotelscreatedticketbyUser(0);
				    user.get().setSubsExpDate(newDate);
					System.out.println(" PAYID "+paydetail.getStripepaymentId());
					userRepository.save(user.get());
		    }
		    
		    response.setMessage("Ticket Subscription success ");
			response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(paydetail);
		    }
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ResponseEntity.status(HttpStatus.OK).body(response);	
}
	
	
	private static Gson gson = new Gson();

    static class CreatePaymentBody {
        @SerializedName("items")
        Object[] items;

        @SerializedName("currency")
        String currency;

        public Object[] getItems() {
            return items;
        }

        public String getCurrency() {
            return currency;
        }
    }

   
    
    
    
//	@PostMapping("/payment-intent")
//	public String  paymentStripe(@RequestBody ChargeRequest charge) throws StripeException
//		{
//		 CustomerCreateParams customerCreateParams = new CustomerCreateParams.Builder().build();
//         Customer customer = Customer.create(customerCreateParams);
//        
//
//         Stripe.apiKey = "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";
//     	
//         CreatePaymentBody postBody = new CreatePaymentBody();
//         PaymentIntentCreateParams createParams = new PaymentIntentCreateParams.Builder()
//                 .setCurrency("USD")
//                 .setAmount((long) charge.getAmount())
//                 .setCustomer(customer.getId())
//                 .build();
//         
//         // Create a PaymentIntent with the order amount and currency and the customer id
//         PaymentIntent intent = PaymentIntent.create(createParams);
//         // Send publishable key and PaymentIntent details to client
//         return gson.toJson(new CreatePaymentResponse("pk_live_51HTrWTGk9TWJsMqYJ1aeqZJm7pLCD7hP9RxKPk6SF5hsUORBW6OTpVmVrDw0o81UysTPcnb1ZS46ql37s9fAGHm500yYIPhtP3", intent.getClientSecret(),
//                 intent.getId()));
//			
//		}
	}