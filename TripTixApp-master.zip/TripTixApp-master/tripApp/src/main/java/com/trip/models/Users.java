package com.trip.models;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Version;
import javax.validation.constraints.Pattern;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModelProperty;

@Entity
public class Users implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@ApiModelProperty(required = false, hidden = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String name;

	@Column(unique = true)
	private String email;

	private String password;

	@ApiModelProperty(required = false, hidden = true)
	private int userRollid;

	@ApiModelProperty(required = false, hidden = true)
	private String caregiverNumber;
	
//	@ApiModelProperty(required = false, hidden = true)
//	private int followers,donations,points;

	public String getCaregiverNumber() {
		return caregiverNumber;
	}

	public void setCaregiverNumber(String caregiverNumber) {
		this.caregiverNumber = caregiverNumber;
	}

	@ApiModelProperty(required = false, hidden = true)
	private String photoUrl, status;

	@Column(unique = true)
	@ApiModelProperty(required = false, hidden = true)
	
	private String mobileNo;

	@ApiModelProperty(required = false, hidden = true)
	private boolean isPublisher;

	@ApiModelProperty(required = false, hidden = true)
	@CreationTimestamp
	private Timestamp timeStamp;

	@ApiModelProperty(required = false, hidden = true)
	@Version
	private Timestamp lastUpdatedon;

	@ApiModelProperty(required = false, hidden = true)
	private boolean isActive = true;

	@ApiModelProperty(required = false, hidden = true)
	private String firstname, lastName, address;
     
	@ApiModelProperty(required = false, hidden = true)
	private String city, state, pinCode;
	
	@ApiModelProperty(required = false, hidden = true)
	private String resetToken;
	
	@ApiModelProperty(required = false, hidden = true)
	private String otp;
	
	@ApiModelProperty(required = false, hidden = true)
	private String amount;
	
	@ApiModelProperty(required = false, hidden = true)
	private String stripepaymentId;
	
	@ApiModelProperty(required = false, hidden = true)
	private String subsDate;
	
	@ApiModelProperty(required = false, hidden = true)
	private int totalTicket;
	
	@ApiModelProperty(required = false, hidden = true)
	private int totelscreatedticketbyUser;
	
	@ApiModelProperty(required = false, hidden = true)
	private String subsExpDate;
	
	@ApiModelProperty(required = false, hidden = true)
	private String subsType;
	
	
	
	public String getSubsType() {
		return subsType;
	}

	public void setSubsType(String subsType) {
		this.subsType = subsType;
	}

	public String getSubsExpDate() {
		return subsExpDate;
	}

	public void setSubsExpDate(String subsExpDate) {
		this.subsExpDate = subsExpDate;
	}

	public int getTotalTicket() {
		return totalTicket;
	}

	public void setTotalTicket(int totalTicket) {
		this.totalTicket = totalTicket;
	}

	public int getTotelscreatedticketbyUser() {
		return totelscreatedticketbyUser;
	}

	public void setTotelscreatedticketbyUser(int remainingTicket) {
		this.totelscreatedticketbyUser = remainingTicket;
	}

	public String getSubsDate() {
		return subsDate;
	}

	public void setSubsDate(String subsDate) {
		this.subsDate = subsDate;
	}

	public String getAmount() {
		return amount;
	}

	
	public void setAmount(String amount) {
		this.amount = amount;
	}

	public void setStripepaymentId(String stripepaymentId) {
		this.stripepaymentId = stripepaymentId;
	}

	public String getStripepaymentId() {
		return stripepaymentId;
	}

	

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getResetToken() {
		return resetToken;
	}

	public void setResetToken(String resetToken) {
		this.resetToken = resetToken;
	}

	public Users(String name, String email, String password, String photo) {

		super();
		this.name = name;
		this.email = email;
		this.password = password;
		this.photoUrl = photo;

	}

	public Users() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

	public boolean isPublisher() {
		return isPublisher;
	}

	public void setPublisher(boolean isPublisher) {
		this.isPublisher = isPublisher;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public Timestamp getLastUpdatedon() {
		return lastUpdatedon;
	}

	public void setLastUpdatedon(Timestamp lastUpdatedon) {
		this.lastUpdatedon = lastUpdatedon;
	}

	/*
	 * public List<Songs> getmSongs() { return mSongs; }
	 * 
	 * 
	 * public void setmSongs(List<Songs> mSongs) { this.mSongs = mSongs; }
	 */

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getUserRollid() {
		return userRollid;
	}

	public void setUserRollid(int userRollid) {
		this.userRollid = userRollid;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	

}
