package com.trip.response;

public class DestinationResponse {
	private String destinationAddress;
    private String destinationCity;
    private String destinationState;
    private String destnationZip;
	public String getDestinationAddress() {
		return destinationAddress;
	}
	public void setDestinationAddress(String destinationAddress) {
		this.destinationAddress = destinationAddress;
	}
	public String getDestinationCity() {
		return destinationCity;
	}
	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}
	public String getDestinationState() {
		return destinationState;
	}
	public void setDestinationState(String destinationState) {
		this.destinationState = destinationState;
	}
	public String getDestnationZip() {
		return destnationZip;
	}
	public void setDestnationZip(String destnationZip) {
		this.destnationZip = destnationZip;
	}
}
