package com.trip.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trip.models.UserRoles;
import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.repo.UserRolesRepo;
import com.trip.requset.CustomResponse;

@RestController
@RequestMapping(path = "/role")
public class UserRolesController {

	@Autowired
	UserRolesRepo rolesRepo;
	
	@Autowired
	private UserRepo userRepository;
	
	@GetMapping
    public CustomResponse findAll() {
    	CustomResponse response = new CustomResponse();
    	try {
    		List<UserRoles> list = rolesRepo.findAll();
    		response.setMessage("Success");
			response.setStatus(true);
			response.setResponseObj(list);
			return response;
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			return response;
		}
    }

    @PostMapping(consumes = "application/json")
    public ResponseEntity<CustomResponse> create(@RequestBody UserRoles r) {
    	
    	CustomResponse response = new CustomResponse();
    	Users user = new Users();
    	try {
    		int roleuserId = r.getRole_id();
    		Optional<Users> userid = userRepository.findById(roleuserId);
    		if(userid.isPresent()==true) {
    			userid.get().setUserRollid(roleuserId);
    			userRepository.save(userid.get());
    		}
    		rolesRepo.save(r);
	    	response.setMessage("Success");
			response.setStatus(true);
			response.setResponseObj(r);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
    	    	
    }
	
}
