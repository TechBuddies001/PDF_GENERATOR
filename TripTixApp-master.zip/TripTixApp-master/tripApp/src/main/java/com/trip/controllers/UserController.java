package com.trip.controllers;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.requset.CustomResponse;
import com.trip.requset.UserDTO;
import com.trip.response.UserDetaileResponse;
import com.trip.services.UserService;

@RestController
@RequestMapping(path = "/user")
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "http://ec2-3-95-217-205.compute-1.amazonaws.com")
public class UserController {

	
	@Autowired
    private UserService service;
	
	@Autowired
	UserRepo userreposiotory;
	
    @GetMapping
    public ResponseEntity<CustomResponse> findAllUsers() {
 
        return service.getAllUsers();
    }

    //SignUp
    @Transactional
    @PostMapping(consumes = "application/json")
    public ResponseEntity<CustomResponse> create(@RequestBody Users user) {
    	
        return service.addUser(user);
        
    }
    
    //update user profile
    @Transactional
    @PostMapping(path = "/updateprofile",consumes = "application/json")
    public ResponseEntity<CustomResponse> updateProfile(@RequestBody UserDTO user) {
    	
        return service.updateuserProfile(user);
        
    }
    
    
    @RequestMapping(value = "/getuserDetail/{userId}", method = RequestMethod.GET)
    public ResponseEntity<CustomResponse> getUserProfile(@PathVariable int userId) {
    	CustomResponse response = new CustomResponse();
    	UserDetaileResponse r = new UserDetaileResponse();
    	Optional<Users> users = userreposiotory.findById(userId);
    	if(users.isPresent()==true) {
    		r.setUserId(users.get().getId());
			r.setName(users.get().getName());
			r.setFirstname(users.get().getFirstname());
			r.setLastName(users.get().getLastName());
			r.setEmail(users.get().getEmail());
			r.setMobileNo(users.get().getMobileNo());
			r.setCity(users.get().getCity());
			r.setAddress(users.get().getAddress());
			r.setPinCode(users.get().getPinCode());
			r.setState(users.get().getState());
			r.setPhotoUrl(users.get().getPhotoUrl());
			r.setActive(users.get().isActive());
			r.setUserRollid(users.get().getUserRollid());
			r.setStatus(users.get().getStatus());	
			response.setMessage("Success");
			response.setStatus(true);
			response.setResponseObj(r);
			return ResponseEntity.status(HttpStatus.OK).body(response);
    	}else {
    		response.setMessage("userId not persent");
			response.setStatus(true);
			response.setResponseObj(r);
			return ResponseEntity.status(HttpStatus.OK).body(response);
    	}
     //   return service.updateuserProfile(user);
        
    }
    
}
