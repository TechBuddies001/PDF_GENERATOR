package com.trip.services;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.trip.models.Region;
import com.trip.repo.RegionRepo;
import com.trip.requset.CustomResponse;

@Service
public class RegionService {

	
	@Autowired
	RegionRepo regionRepo;
	
	public Page<Region> getRegionsByPage(Pageable page) {
		try {
			return regionRepo.findAll(page);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
	
	public CustomResponse findAllRegions() {
    	CustomResponse response = new CustomResponse();
    	try {
    		List<Region> list = regionRepo.findAll();
    		response.setMessage("Success");
			response.setStatus(true);
			response.setResponseObj(list);
			return response;
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			return response;
		}
    }

	public ResponseEntity<CustomResponse> save(Region reg) {
		CustomResponse response = new CustomResponse();
    	try {
    		regionRepo.save(reg);
	    	response.setMessage("Success");
			response.setStatus(true);
			response.setStatusCode(200);
			response.setResponseObj(reg);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
		
	}

	
	public ResponseEntity<CustomResponse> searchRegion(String key) {
		CustomResponse response = new CustomResponse();
		try {
			List<Region> mRegion = regionRepo.searchBykeyword(key);
			response.setMessage("Success");
			response.setStatus(true);
			response.setStatusCode(200);
			HashMap<String,List<Region>> map=new HashMap<String,List<Region>>();
			map.put("content", mRegion);
			response.setResponseObj(map);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error: "+e.getLocalizedMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}
	
}
