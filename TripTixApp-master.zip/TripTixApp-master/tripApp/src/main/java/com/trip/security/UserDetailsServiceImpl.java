package com.trip.security;

import java.util.Collections;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.trip.models.Users;
import com.trip.repo.UserRepo;

@Service
public class UserDetailsServiceImpl implements UserDetailsService{

	private UserRepo applicationUserRepository;

    public UserDetailsServiceImpl(UserRepo applicationUserRepository) {
        this.applicationUserRepository = applicationUserRepository;
    }
	
	@Override
	public UserDetails loadUserByUsername(String userEmail) throws UsernameNotFoundException {
		
		Users applicationUser = applicationUserRepository.findByEmailIgnoreCase(userEmail);
        if (applicationUser == null) {
            throw new UsernameNotFoundException(userEmail);
        }
        return new User(applicationUser.getEmail(), applicationUser.getPassword(), Collections.emptyList());
	}
	
	
	

}
