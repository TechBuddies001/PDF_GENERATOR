package com.trip.response;

public class TransferingRegistrant {
	private String tLegalName;
	private String tCardNumber;
	private String tLegalNameifApplicable;
	private String tRegistrationCertificateNuberifApplicable;

	public String gettLegalName() {
		return tLegalName;
	}

	public void settLegalName(String tLegalName) {
		this.tLegalName = tLegalName;
	}

	public String gettCardNumber() {
		return tCardNumber;
	}

	public void settCardNumber(String tCardNumber) {
		this.tCardNumber = tCardNumber;
	}

	public String gettLegalNameifApplicable() {
		return tLegalNameifApplicable;
	}

	public void settLegalNameifApplicable(String tLegalNameifApplicable) {
		this.tLegalNameifApplicable = tLegalNameifApplicable;
	}

	public String gettRegistrationCertificateNuberifApplicable() {
		return tRegistrationCertificateNuberifApplicable;
	}

	public void settRegistrationCertificateNuberifApplicable(String tRegistrationCertificateNuberifApplicable) {
		this.tRegistrationCertificateNuberifApplicable = tRegistrationCertificateNuberifApplicable;
	}

}
