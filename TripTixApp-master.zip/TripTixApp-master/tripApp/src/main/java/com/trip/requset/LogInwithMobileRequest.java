package com.trip.requset;

public class LogInwithMobileRequest {
private int userId;
private String otp;

public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getOtp() {
	return otp;
}
public void setOtp(String otp) {
	this.otp = otp;
}
}
