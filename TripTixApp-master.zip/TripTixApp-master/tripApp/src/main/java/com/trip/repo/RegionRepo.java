package com.trip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.trip.models.Region;

@RepositoryRestResource
public interface RegionRepo extends JpaRepository<Region, Integer> {

	
	//Search all regions query
	@Query(value="SELECT * FROM region WHERE name like %:keyword%", nativeQuery = true)
	List<Region> searchBykeyword(@Param("keyword")String key);

	
// OR
//	public List<Users> findByFnameOrLnameIgnoreCase(String fname, String lname);

//	@Query(value="SELECT Count(*) FROM Users WHERE time_stamp > ?1", nativeQuery = true)
//	public int findNewUsersCount(String lastweekdate);
//	
//	@Query(value="SELECT Count(*) FROM Event WHERE organised_by_id = ?1", nativeQuery = true)
//	public int findTotalEventsByArtist(int artistId);

}
