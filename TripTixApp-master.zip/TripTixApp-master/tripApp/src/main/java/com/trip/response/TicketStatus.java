package com.trip.response;

public class TicketStatus {
private int ticketId;
private int completedformNo;
private String formStatus;
private int userId;
public int getTicketId() {
	return ticketId;
}
public void setTicketId(int ticketId) {
	this.ticketId = ticketId;
}
public int getCompletedformNo() {
	return completedformNo;
}
public void setCompletedformNo(int formNo) {
	this.completedformNo = formNo;
}
public String getFormStatus() {
	return formStatus;
}
public void setFormStatus(String formStatus) {
	this.formStatus = formStatus;
}
public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}

}
