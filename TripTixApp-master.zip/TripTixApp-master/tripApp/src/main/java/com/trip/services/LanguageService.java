package com.trip.services;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.trip.models.Language;
import com.trip.repo.LanguageRepo;
import com.trip.requset.CustomResponse;

@Service
public class LanguageService {

	
	@Autowired
	LanguageRepo langRepo;
	
	public Page<Language> getLanguagesByPage(Pageable page) {
		try {
			return langRepo.findAll(page);
		} catch (Exception e) {
			System.out.println(e);
			return null;
		}

	}
	
	public CustomResponse findAllLanguages() {
    	CustomResponse response = new CustomResponse();
    	try {
    		List<Language> list = langRepo.findAll();
    		response.setMessage("Success");
			response.setStatus(true);
			response.setResponseObj(list);
			return response;
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			return response;
		}
    }

	public ResponseEntity<CustomResponse> save(Language cat) {
		CustomResponse response = new CustomResponse();
    	try {
    		langRepo.save(cat);
	    	response.setMessage("Success");
			response.setStatus(true);
			response.setStatusCode(200);
			response.setResponseObj(cat);
			return ResponseEntity.status(HttpStatus.OK).body(response);
	    	
    	}catch (Exception e) {
    		response.setMessage("Error: "+e.getMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
		
	}

	
	public ResponseEntity<CustomResponse> searchLanguage(String key) {
		CustomResponse response = new CustomResponse();
		try {
			List<Language> mLang = langRepo.searchBykeyword(key);
			response.setMessage("Success");
			response.setStatus(true);
			response.setStatusCode(200);
			HashMap<String,List<Language>> map=new HashMap<String,List<Language>>();
			map.put("content", mLang);
			response.setResponseObj(map);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} catch (Exception e) {
			response.setMessage("Error: "+e.getLocalizedMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
	}
	
}
