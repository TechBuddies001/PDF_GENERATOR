package com.trip.response;

public class UserResponse {
	
	private int userId;
	
    private String name;
    private String email;
    private boolean active;
    private String rollAs;
    private String photoUrl;
    private boolean paymentStatus;
	public UserResponse() {
		super();
	}
	public UserResponse(int userId, String name, String email, boolean active, String rollAs, String photoUrl) {
		super();
		this.userId = userId;
		this.name = name;
		this.email = email;
		this.active = active;
		this.rollAs = rollAs;
		this.photoUrl = photoUrl;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getRollAs() {
		return rollAs;
	}
	public void setRollAs(String rollAs) {
		this.rollAs = rollAs;
	}
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	public boolean isPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(boolean paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	@Override
	public String toString() {
		return "UserResponse [userId=" + userId + ", name=" + name + ", email=" + email + ", active=" + active
				+ ", rollAs=" + rollAs + ", photoUrl=" + photoUrl + "]";
	}

    

}
