package com.trip.response;

public class RecevingPatient {
public String recevingPatientmedicalcNumber;

public String getRecevingPatientmedicalcNumber() {
	return recevingPatientmedicalcNumber;
}

public void setRecevingPatientmedicalcNumber(String recevingPatientmedicalcNumber) {
	this.recevingPatientmedicalcNumber = recevingPatientmedicalcNumber;
}
}
