package com.trip.requset;

public class TripticketRequest {
	private String legalName;
	private String registryIdentificationCardnumber;
	private String nameofRegistrationCertificateholder;
	private String registrationCertificateNumber;
	private int userId;

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String getRegistryIdentificationCardnumber() {
		return registryIdentificationCardnumber;
	}

	public void setRegistryIdentificationCardnumber(String registryIdentificationCardnumber) {
		this.registryIdentificationCardnumber = registryIdentificationCardnumber;
	}

	public String getNameofRegistrationCertificateholder() {
		return nameofRegistrationCertificateholder;
	}

	public void setNameofRegistrationCertificateholder(String nameofRegistrationCertificateholder) {
		this.nameofRegistrationCertificateholder = nameofRegistrationCertificateholder;
	}

	public String getRegistrationCertificateNumber() {
		return registrationCertificateNumber;
	}

	public void setRegistrationCertificateNumber(String registrationCertificateNumber) {
		this.registrationCertificateNumber = registrationCertificateNumber;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
