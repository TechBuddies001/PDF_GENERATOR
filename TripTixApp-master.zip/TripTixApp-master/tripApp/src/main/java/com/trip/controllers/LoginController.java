package com.trip.controllers;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.trip.models.UserRoles;
import com.trip.models.Users;
import com.trip.repo.UserRolesRepo;
import com.trip.requset.CustomResponse;
import com.trip.requset.LoginCred;
import com.trip.response.UserResponse;
import com.trip.security.JwtTokenUtil;
import com.trip.services.UserService;

@RestController
@RequestMapping(path = "/login")

public class LoginController {

//	@Autowired
//	private AuthenticationManager authenticationManager;

	@Autowired
	private UserService service;

	@Autowired
	ObjectMapper mapper;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	UserRolesRepo rolesRepo;

	// Login
	@PostMapping(path = "/check",consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomResponse> checkUserLogin(@RequestBody LoginCred loginObj) {

		CustomResponse response = new CustomResponse();
		UserResponse userdetails = new UserResponse();
		try {

			/*
			 * final Authentication authentication = authenticationManager.authenticate( new
			 * UsernamePasswordAuthenticationToken(loginObj.getEmail(),loginObj.getPassword(
			 * ) ) );
			 * 
			 * SecurityContextHolder.getContext().setAuthentication(authentication);
			 */
			 

			String passswd = "";
			Users user = service.getUser(loginObj.getEmail());
			if (user != null) {

				passswd = user.getPassword();

				//if (loginObj.getPassword().equalsIgnoreCase(passswd)) {
			 if(bCryptPasswordEncoder.matches(loginObj.getPassword(), passswd)) {
				 Optional<UserRoles> role = rolesRepo.findById(user.getId());
				 if(role.isPresent()==true) {
					 userdetails.setRollAs(role.get().getTitle());
				 }
				    userdetails.setUserId(user.getId());
				    userdetails.setName(user.getName());
				    userdetails.setEmail(user.getEmail());
				    userdetails.setActive(user.isActive());
				    userdetails.setPhotoUrl(user.getPhotoUrl());
				    
					response.setMessage("Success");
					response.setStatusCode(200);
					response.setStatus(true);
					ObjectNode object = mapper.createObjectNode();
					object.put("token", jwtTokenUtil.generateToken(user.getEmail()));
					object.putPOJO("User", userdetails);
					response.setResponseObj(object);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response.setMessage("Invalid Email/Password");
					response.setStatus(false);
					response.setStatusCode(200);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}

			} else {
				response.setMessage("Invalid Email");
				response.setStatus(false);
				response.setStatusCode(200);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}

		} catch (Exception e) {
			response.setMessage("Error :" + e.getLocalizedMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}

	}

	//SignUp
    @PostMapping(path = "/create",consumes = "application/json")
    public ResponseEntity<CustomResponse> create(@RequestBody Users user) {
    	
        return service.addUser(user);
        
    }
	
}
