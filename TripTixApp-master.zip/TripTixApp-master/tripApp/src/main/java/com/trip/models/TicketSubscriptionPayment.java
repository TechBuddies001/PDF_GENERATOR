package com.trip.models;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Version;

import org.hibernate.annotations.CreationTimestamp;

import io.swagger.annotations.ApiModelProperty;
@Entity
public class TicketSubscriptionPayment implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@ApiModelProperty(required = false, hidden = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	private String amount;
	
	private String subscriptionType;
	
	private int totalTicket;
	
	private int userId;
	
	private String subsDate;
	
	@ApiModelProperty(required = false, hidden = true)
	private String stripepaymentId;
	
	@ApiModelProperty(required = false, hidden = true)
	@CreationTimestamp
	private Timestamp timeStamp;
	
	@ApiModelProperty(required = false, hidden = true)
	@Version
	private Timestamp lastUpdatedon;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public int getTotalTicket() {
		return totalTicket;
	}

	public void setTotalTicket(int totalTicket) {
		this.totalTicket = totalTicket;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getSubsDate() {
		return subsDate;
	}

	public void setSubsDate(String subsDate) {
		this.subsDate = subsDate;
	}

	public String getStripepaymentId() {
		return stripepaymentId;
	}

	public void setStripepaymentId(String stripepaymentId) {
		this.stripepaymentId = stripepaymentId;
	}

	public Timestamp getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(Timestamp timeStamp) {
		this.timeStamp = timeStamp;
	}

	public Timestamp getLastUpdatedon() {
		return lastUpdatedon;
	}

	public void setLastUpdatedon(Timestamp lastUpdatedon) {
		this.lastUpdatedon = lastUpdatedon;
	}
	
	
	
}
