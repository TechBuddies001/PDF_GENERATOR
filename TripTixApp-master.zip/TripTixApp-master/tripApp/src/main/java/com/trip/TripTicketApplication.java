package com.trip;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.trip.requset.FileStorageProperties;
import com.trip.requset.StorageProperties;


@EnableConfigurationProperties({
	FileStorageProperties.class
})

@SpringBootApplication
public class TripTicketApplication implements WebMvcConfigurer{

	public static void main(String[] args) {
		SpringApplication.run(TripTicketApplication.class, args);	
	}	  
	
	  @Override public void addCorsMappings(CorsRegistry registry) {
	  
	  registry.addMapping("/**").allowedMethods("GET","POST","PUT", "DELETE"); //
	  //.allowedOrigins("http://ec2-3-95-217-205.compute-1.amazonaws.com");
	  //.allowedOrigins("http://localhost:4200") ; 
	  }
	 
	 
	 @Bean
	    public BCryptPasswordEncoder bCryptPasswordEncoder() {
	        return new BCryptPasswordEncoder();
	    }
	  
	 	 	  
}
