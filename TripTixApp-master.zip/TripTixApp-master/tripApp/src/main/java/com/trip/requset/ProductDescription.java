package com.trip.requset;

public class ProductDescription {
	
	private int tripticketId;
	private String DescriptionofProducts;
	
	public int getTripticketId() {
		return tripticketId;
	}
	public void setTripticketId(int tripticketId) {
		this.tripticketId = tripticketId;
	}
	public String getDescriptionofProducts() {
		return DescriptionofProducts;
	}
	public void setDescriptionofProducts(String descriptionofProducts) {
		DescriptionofProducts = descriptionofProducts;
	}

}
