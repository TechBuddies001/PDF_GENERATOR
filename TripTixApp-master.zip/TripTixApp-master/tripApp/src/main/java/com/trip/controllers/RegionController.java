package com.trip.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trip.models.Region;
import com.trip.requset.CustomResponse;
import com.trip.services.RegionService;

@RestController
@RequestMapping(path = "/region")
public class RegionController {

	@Autowired
	RegionService service;
	
	
	
	// Search from all regions
	@GetMapping(path = "/search/{keyword}")
	public ResponseEntity<CustomResponse> searchAllRegions(@PathVariable("keyword") String key) {
				return service.searchRegion(key);
			}
		
	// GET All Regions by page
	@GetMapping(value = "/page/{page}/{size}")
	public CustomResponse findAllRegionsByPage(@PathVariable("page") int page,@PathVariable("size") int size) {
		    	CustomResponse response = new CustomResponse();
		    	try {
		    		Pageable pageRequest = PageRequest.of(page, size,Sort.by("id").descending());
		    		Page<Region> list = service.getRegionsByPage(pageRequest);
		    		
		    		response.setMessage("Success");
					response.setStatus(true);
					response.setStatusCode(200);
					response.setResponseObj(list);
					return response;
		    	}catch (Exception e) {
		    		System.out.println(e);
		    		response.setMessage("Error");
					response.setStatus(false);
					response.setStatusCode(500);
					return response;
				}
		    }

	
	//Find all
	@GetMapping
    public CustomResponse findAllRegion() {
    	return service.findAllRegions();
    }

	//Create new 
    @PostMapping(consumes = "application/json")
    public ResponseEntity<CustomResponse> create(@RequestBody Region region) {
    	return service.save(region);
    	    	
    }
	
}
