package com.trip.security;

import java.io.Serializable;
import java.util.Date;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

@Component
public class JwtTokenUtil implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public String getEmailFromToken(String token) {
		
		return JWT.require(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()))
                .build()
                .verify(token.replace(SecurityConstants.TOKEN_PREFIX, ""))
                .getSubject();
	}


	public String generateToken(String email) {
		return doGenerateToken(email);
	}

	private String doGenerateToken(String subject) {

		String token = JWT.create()
                .withSubject(subject)
                .withExpiresAt(new Date(System.currentTimeMillis() + SecurityConstants.EXPIRATION_TIME))
                .sign(Algorithm.HMAC512(SecurityConstants.SECRET.getBytes()));
		
		return token;
	}

	public Boolean validateToken(String token, UserDetails userDetails) {
		final String username = getEmailFromToken(token);
		return (username.equals(userDetails.getUsername()));
	}
}
