package com.trip.requset;

public class AddSignature {
	
	private byte[] digitalSignature;
	private int tripticketId;
	
	
	public byte[] getDigitalSignature() {
		return digitalSignature;
	}
	public void setDigitalSignature(byte[] digitalSignature) {
		this.digitalSignature = digitalSignature;
	}
	public int getTripticketId() {
		return tripticketId;
	}
	public void setTripticketId(int tripticketId) {
		this.tripticketId = tripticketId;
	}

}
