package com.trip.requset;

public class DepartureInformation {
	private int tripticketId;
	private String departureStartdate;
	private String departureStarttime;
    private String departureAddress;
    private String departureCity;
    private String departureState;
    private String departureZip;
    
	public int getTripticketId() {
		return tripticketId;
	}
	public void setTripticketId(int tripticketId) {
		this.tripticketId = tripticketId;
	}
	public String getDepartureStartdate() {
		return departureStartdate;
	}
	public void setDepartureStartdate(String departureStartdate) {
		this.departureStartdate = departureStartdate;
	}
	public String getDepartureStarttime() {
		return departureStarttime;
	}
	public void setDepartureStarttime(String departureStarttime) {
		this.departureStarttime = departureStarttime;
	}
	public String getDepartureAddress() {
		return departureAddress;
	}
	public void setDepartureAddress(String departureAddress) {
		this.departureAddress = departureAddress;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getDepartureState() {
		return departureState;
	}
	public void setDepartureState(String departureState) {
		this.departureState = departureState;
	}
	public String getDepartureZip() {
		return departureZip;
	}
	public void setDepartureZip(String departureZip) {
		this.departureZip = departureZip;
	}
}
