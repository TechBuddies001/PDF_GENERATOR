package com.trip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.trip.models.TripTicketform;

@Repository
public interface TripformRepo extends JpaRepository<TripTicketform, Integer>{

	@Query(value = "SELECT * FROM trip_ticketform u WHERE u.userId = ?1", nativeQuery = true)
	List<TripTicketform> findByuserId(int userId);

	@Query(value = "SELECT * FROM trip_ticketform u WHERE u.userId = ?1 and u.f_status =?2", nativeQuery = true)
	List<TripTicketform> findStatusByuserId(int userId, String f_status);

	//DISTINCT
	//@Query("SELECT DISTINCT a.destination_address FROM trip_ticketform a);
	
	
	@Query(value = "SELECT * FROM trip_ticketform u WHERE u.userId = ?1", nativeQuery = true)
	List<TripTicketform> getDepartureList(int userId);

	@Query(value = "SELECT count(*) FROM trip_ticketform u WHERE u.userId = ?1", nativeQuery = true)
	int countcreatedticket(int userId);

}
