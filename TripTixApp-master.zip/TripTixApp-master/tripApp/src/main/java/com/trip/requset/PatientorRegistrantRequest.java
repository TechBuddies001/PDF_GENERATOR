package com.trip.requset;

public class PatientorRegistrantRequest {
private int tripTicketId;
//private int userId;
private String patientidentificationumberorMedicalCertificationNumber;
private String rplegalName;
private String rpregistryIdentificationCardnumber;
private String rpnameofRegistrationCertificateholder;
private String rpregistrationCertificateNumber;


public String getRplegalName() {
	return rplegalName;
}
public void setRplegalName(String rplegalName) {
	this.rplegalName = rplegalName;
}
public String getRpregistryIdentificationCardnumber() {
	return rpregistryIdentificationCardnumber;
}
public void setRpregistryIdentificationCardnumber(String rpregistryIdentificationCardnumber) {
	this.rpregistryIdentificationCardnumber = rpregistryIdentificationCardnumber;
}
public String getRpnameofRegistrationCertificateholder() {
	return rpnameofRegistrationCertificateholder;
}
public void setRpnameofRegistrationCertificateholder(String rpnameofRegistrationCertificateholder) {
	this.rpnameofRegistrationCertificateholder = rpnameofRegistrationCertificateholder;
}
public String getRpregistrationCertificateNumber() {
	return rpregistrationCertificateNumber;
}
public void setRpregistrationCertificateNumber(String rpregistrationCertificateNumber) {
	this.rpregistrationCertificateNumber = rpregistrationCertificateNumber;
}
public int getTripTicketId() {
	return tripTicketId;
}
public void setTripTicketId(int tripTicketId) {
	this.tripTicketId = tripTicketId;
}

public String getPatientidentificationumberorMedicalCertificationNumber() {
	return patientidentificationumberorMedicalCertificationNumber;
}
public void setPatientidentificationumberorMedicalCertificationNumber(
		String patientidentificationumberorMedicalCertificationNumber) {
	this.patientidentificationumberorMedicalCertificationNumber = patientidentificationumberorMedicalCertificationNumber;
}

}
