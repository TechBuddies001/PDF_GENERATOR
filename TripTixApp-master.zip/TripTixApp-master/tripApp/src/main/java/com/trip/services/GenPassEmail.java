package com.trip.services;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.trip.requset.Email;

@Service
public class GenPassEmail {

	
	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired
	SpringTemplateEngine templateEngine;



	public GenPassEmail(JavaMailSender javaMailSender) {
		super();
		this.javaMailSender = javaMailSender;
	}
	
	@Autowired
	private JavaMailSender mailSender;

	@Async
	public void sendEmail(SimpleMailMessage email) {
		mailSender.send(email);
	}
	
	public void sendWelcomeMail(String receiverEmail,String password) {
		
		
		Email mail = new Email();
//        mail.setFrom("honey.rana@Ftechiz.com");
//        mail.setFrom("honeyrana.myappsdevelopment@outlook.com");
//        mail.setTo(receiverEmail);
//        mail.setSubject("Music For Life Verification Email.");
		
		Map<String,Object> model = new HashMap<String,Object>();
        model.put("email", receiverEmail);
        model.put("password", password);
        mail.setVariablesModel(model);
		
		MimeMessage mimeMsg=javaMailSender.createMimeMessage();
		
		try {
			
			MimeMessageHelper msgHelper=new MimeMessageHelper(mimeMsg,
	                MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
	                StandardCharsets.UTF_8.name());
			
			msgHelper.setFrom("om.prakash@ftechiz.com");
			msgHelper.setTo(receiverEmail);
			msgHelper.setSubject("Trip Tix Verification Email.");
			//msgHelper.addAttachment("logo.jpg", new ClassPathResource("logo.jpg"));

	        
			Context context = new Context();
	        context.setVariables(model);
			String html = templateEngine.process("EmailTemplate", context);
			msgHelper.setText(html, true);
			
			javaMailSender.send(mimeMsg);
			
			/*
			 * msgHelper.setText("Welcome "+user.getFname()
			 * +" "+user.getLname()+" Lorem ipsum dolor sit amet, " +
			 * "consectetur adipiscing elit. Curabitur eu molestie ligula. Interdum et malesuada fames ac "
			 * +
			 * "ante ipsum primis in faucibus. Morbi at faucibus nunc. Vestibulum sagittis, ligula a dictum "
			 * +
			 * "suscipit, felis libero molestie ipsum, in laoreet odio eros eu neque. Quisque iaculis tristique hendrerit."
			 * +
			 * " Vivamus pulvinar massa nec orci facilisis facilisis. Vivamus eu facilisis elit, vitae ultrices augue."
			 * +
			 * " Nam dictum dignissim magna, ac vehicula diam venenatis ac. Integer sollicitudin pharetra ligula, "
			 * +
			 * " eu molestie justo interdum vel. Etiam sagittis viverra tortor, in rhoncus tellus tristique eu."
			 * +
			 * " Sed pharetra lectus euismod mauris tincidunt, elementum pharetra nulla fringilla."
			 * );
			 */
			  
			  //FileSystemResource file = new FileSystemResource(new File("C:\\Users\\HP\\Downloads\\blackImg.JPG"));
			  
			 
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	 
	
	
	
	/*
	 * public void sendWelcomeMail(User user) {
	 * 
	 * SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
	 * simpleMailMessage.setFrom("honey.rana@Ftechiz.com");
	 * simpleMailMessage.setTo("erhoneyrana@gmail.com");
	 * simpleMailMessage.setSubject("Simple Mail Msg SpringBoot");;
	 * simpleMailMessage.setText("Welcome "+user.getFname()
	 * +user.getLname()+" Lorem ipsum dolor sit amet, " +
	 * "consectetur adipiscing elit. Curabitur eu molestie ligula. Interdum et malesuada fames ac "
	 * +
	 * "ante ipsum primis in faucibus. Morbi at faucibus nunc. Vestibulum sagittis, ligula a dictum "
	 * +
	 * "suscipit, felis libero molestie ipsum, in laoreet odio eros eu neque. Quisque iaculis tristique hendrerit."
	 * +
	 * " Vivamus pulvinar massa nec orci facilisis facilisis. Vivamus eu facilisis elit, vitae ultrices augue."
	 * +
	 * " Nam dictum dignissim magna, ac vehicula diam venenatis ac. Integer sollicitudin pharetra ligula, "
	 * +
	 * " eu molestie justo interdum vel. Etiam sagittis viverra tortor, in rhoncus tellus tristique eu."
	 * +
	 * " Sed pharetra lectus euismod mauris tincidunt, elementum pharetra nulla fringilla."
	 * );
	 * 
	 * javaMailSender.send(simpleMailMessage); }
	 */
	
	
}
