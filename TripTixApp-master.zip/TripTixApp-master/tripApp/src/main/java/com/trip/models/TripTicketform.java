package com.trip.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;
@Entity
public class TripTicketform {
	@Id
	@ApiModelProperty(required = false, hidden = true)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String legalName ;
	private String registryIdentificationCardnumber;
	private String nameofRegistrationCertificateholder;
	private String registrationCertificateNumber;
	
	private String patientidentificationumberorMedicalCertificationNumber;
	private String receivinglegalName;
	private String receivingregistryIdentificationCardnumber;
	private String receivingnameofRegistrationCertificateholder;
	private String receivingregistrationCertificateNumber;
	
	
	private String descriptionofProducts;
	
	private String departureStartdate;
	private String departureStarttime;
    private String departureAddress;
    private String departureCity;
    private String departureState;
    private String departureZip;

    private String destinationdate;
	private String destinationtime;
    private String destinationAddress;
    private String destinationCity;
    private String destinationState;
    private String destnationZip;
    
    
		private String nameofReceivingRegistrant;
    	private String emailAddress;
    	private String PhoneNumber;
    	private String dateReceived;
    	private String timeReceived;
    	
    	
    	private String digitalSignature;
    	
    	 @Lob
    	 private byte[] signature;
    	 
    	 
	     private int userID;
	     
	  private int formNo;
	  private String fStatus;
	  
	  
	    public byte[] getSignature() {
		return signature;
	}
	public void setSignature(byte[] signature) {
		this.signature = signature;
	}
		public int getFormNo() {
			return formNo;
		}
		public void setFormNo(int formNo) {
			this.formNo = formNo;
		}
		public String getfStatus() {
			return fStatus;
		}
		public void setfStatus(String fStatus) {
			this.fStatus = fStatus;
		}
		public String getLegalName() {
			return legalName;
		}
		public void setLegalName(String legalName) {
			this.legalName = legalName;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public int getUserID() {
			return userID;
		}
		public void setUserID(int userID) {
			this.userID = userID;
		}
		public String getRegistryIdentificationCardnumber() {
			return registryIdentificationCardnumber;
		}
		public void setRegistryIdentificationCardnumber(String registryIdentificationCardnumber) {
			this.registryIdentificationCardnumber = registryIdentificationCardnumber;
		}
		public String getNameofRegistrationCertificateholder() {
			return nameofRegistrationCertificateholder;
		}
		public void setNameofRegistrationCertificateholder(String nameofRegistrationCertificateholder) {
			this.nameofRegistrationCertificateholder = nameofRegistrationCertificateholder;
		}
		public String getRegistrationCertificateNumber() {
			return registrationCertificateNumber;
		}
		public void setRegistrationCertificateNumber(String registrationCertificateNumber) {
			this.registrationCertificateNumber = registrationCertificateNumber;
		}
		public String getPatientidentificationumberorMedicalCertificationNumber() {
			return patientidentificationumberorMedicalCertificationNumber;
		}
		public void setPatientidentificationumberorMedicalCertificationNumber(
				String patientidentificationumberorMedicalCertificationNumber) {
			this.patientidentificationumberorMedicalCertificationNumber = patientidentificationumberorMedicalCertificationNumber;
		}
		public String getDescriptionofProducts() {
			return descriptionofProducts;
		}
		public void setDescriptionofProducts(String descriptionofProducts) {
			this.descriptionofProducts = descriptionofProducts;
		}
		public String getDepartureStartdate() {
			return departureStartdate;
		}
		public void setDepartureStartdate(String departureStartdate) {
			this.departureStartdate = departureStartdate;
		}
		public String getDepartureStarttime() {
			return departureStarttime;
		}
		public void setDepartureStarttime(String departureStarttime) {
			this.departureStarttime = departureStarttime;
		}
		public String getDepartureAddress() {
			return departureAddress;
		}
		public void setDepartureAddress(String departureAddress) {
			this.departureAddress = departureAddress;
		}
		public String getDepartureCity() {
			return departureCity;
		}
		public void setDepartureCity(String departureCity) {
			this.departureCity = departureCity;
		}
		public String getDepartureState() {
			return departureState;
		}
		public void setDepartureState(String departureState) {
			this.departureState = departureState;
		}
		public String getDepartureZip() {
			return departureZip;
		}
		public void setDepartureZip(String departureZip) {
			this.departureZip = departureZip;
		}
		public String getDestinationdate() {
			return destinationdate;
		}
		public void setDestinationdate(String destinationdate) {
			this.destinationdate = destinationdate;
		}
		public String getDestinationtime() {
			return destinationtime;
		}
		public void setDestinationtime(String destinationtime) {
			this.destinationtime = destinationtime;
		}
		public String getDestinationAddress() {
			return destinationAddress;
		}
		public void setDestinationAddress(String destinationAddress) {
			this.destinationAddress = destinationAddress;
		}
		public String getDestinationCity() {
			return destinationCity;
		}
		public void setDestinationCity(String destinationCity) {
			this.destinationCity = destinationCity;
		}
		public String getDestinationState() {
			return destinationState;
		}
		public void setDestinationState(String destinationState) {
			this.destinationState = destinationState;
		}
		public String getDestnationZip() {
			return destnationZip;
		}
		public void setDestnationZip(String destnationZip) {
			this.destnationZip = destnationZip;
		}
		public String getNameofReceivingRegistrant() {
			return nameofReceivingRegistrant;
		}
		public void setNameofReceivingRegistrant(String nameofReceivingRegistrant) {
			this.nameofReceivingRegistrant = nameofReceivingRegistrant;
		}
		public String getEmailAddress() {
			return emailAddress;
		}
		public void setEmailAddress(String emailAddress) {
			this.emailAddress = emailAddress;
		}
		public String getPhoneNumber() {
			return PhoneNumber;
		}
		public void setPhoneNumber(String phoneNumber) {
			PhoneNumber = phoneNumber;
		}
		public String getDateReceived() {
			return dateReceived;
		}
		public void setDateReceived(String dateReceived) {
			this.dateReceived = dateReceived;
		}
		public String getTimeReceived() {
			return timeReceived;
		}
		public void setTimeReceived(String timeReceived) {
			this.timeReceived = timeReceived;
		}
		public String getDigitalSignature() {
			return digitalSignature;
		}
		public void setDigitalSignature(String digitalSignature) {
			this.digitalSignature = digitalSignature;
		}
		public String getReceivinglegalName() {
			return receivinglegalName;
		}
		public void setReceivinglegalName(String receivinglegalName) {
			this.receivinglegalName = receivinglegalName;
		}
		public String getReceivingregistryIdentificationCardnumber() {
			return receivingregistryIdentificationCardnumber;
		}
		public void setReceivingregistryIdentificationCardnumber(String receivingregistryIdentificationCardnumber) {
			this.receivingregistryIdentificationCardnumber = receivingregistryIdentificationCardnumber;
		}
		public String getReceivingnameofRegistrationCertificateholder() {
			return receivingnameofRegistrationCertificateholder;
		}
		public void setReceivingnameofRegistrationCertificateholder(String receivingnameofRegistrationCertificateholder) {
			this.receivingnameofRegistrationCertificateholder = receivingnameofRegistrationCertificateholder;
		}
		public String getReceivingregistrationCertificateNumber() {
			return receivingregistrationCertificateNumber;
		}
		public void setReceivingregistrationCertificateNumber(String receivingregistrationCertificateNumber) {
			this.receivingregistrationCertificateNumber = receivingregistrationCertificateNumber;
		}
		
	     
}
