package com.trip.response;

public class ReceiptResponse {
	private String rprintedName;
	private String rEmail;
	private String rPhonNumber;

	public String getRprintedName() {
		return rprintedName;
	}

	public void setRprintedName(String rprintedName) {
		this.rprintedName = rprintedName;
	}

	public String getrEmail() {
		return rEmail;
	}

	public void setrEmail(String rEmail) {
		this.rEmail = rEmail;
	}

	public String getrPhonNumber() {
		return rPhonNumber;
	}

	public void setrPhonNumber(String rPhonNumber) {
		this.rPhonNumber = rPhonNumber;
	}

}
