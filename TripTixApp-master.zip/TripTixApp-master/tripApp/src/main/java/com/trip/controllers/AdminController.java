package com.trip.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trip.requset.CustomResponse;
import com.trip.services.UserService;

@RestController
//@CrossOrigin(origins = "http://localhost:4200")
//@CrossOrigin(origins = "http://ec2-3-95-217-205.compute-1.amazonaws.com")
@RequestMapping(path = "/admin")
public class AdminController {

	@Autowired
	private UserService user_service;

	// Get Users by page
	@GetMapping(value = "/page/{page}/{size}")
	public ResponseEntity<CustomResponse> getUsersByPage(@PathVariable("page") int pageNo,
			@PathVariable("size") int size) {

		return user_service.findUsersByPage(pageNo, size);
	}

	@GetMapping(path = "/{keyword}")
	public ResponseEntity<CustomResponse> searchAllUsers(@PathVariable("keyword") String key) {
		return user_service.searchUsers(key);
	}

	@PutMapping(path = "activeInactive/{id}")
	public ResponseEntity<CustomResponse> updateActiveInActiveState(@PathVariable("id") int id) {

		return user_service.updateActiveToInActiveState(id);

	}
	
//	@PutMapping(path = "InctivetoActive/{id}")
//	public ResponseEntity<CustomResponse> updateIActiveToActiveState(@PathVariable("id") int id) {
//
//		return user_service.updateIActiveToActiveState(id);
//
//	}

	@DeleteMapping(path = "/{id}")
	public ResponseEntity<CustomResponse> delete(@PathVariable int id) {
		return user_service.delete(id);
	}

	@GetMapping(value = "/countActiveInaciveusers")
	public ResponseEntity<CustomResponse> countUser() {

		return user_service.countUser();
	}
}
