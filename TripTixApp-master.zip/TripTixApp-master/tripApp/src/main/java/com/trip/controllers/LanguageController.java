package com.trip.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.trip.models.Language;
import com.trip.requset.CustomResponse;
import com.trip.services.LanguageService;

@RestController
@RequestMapping(path = "/lang")
public class LanguageController {

	
	@Autowired
	private LanguageService service;

	
	// Search from all Languages
	@GetMapping(path = "/search/{keyword}")
	public ResponseEntity<CustomResponse> searchAllLanguages(@PathVariable("keyword") String key) {
			return service.searchLanguage(key);
		}
	
	// GET All Languages by page
	@GetMapping(value = "/page/{page}/{size}")
	public CustomResponse findAllArtistsByPage(@PathVariable("page") int page,@PathVariable("size") int size) {
	    	CustomResponse response = new CustomResponse();
	    	try {
	    		Pageable pageRequest = PageRequest.of(page, size, Sort.by("id").descending());
	    		Page<Language> list = service.getLanguagesByPage(pageRequest);
	    		
	    		response.setMessage("Success");
				response.setStatus(true);
				response.setStatusCode(200);
				response.setResponseObj(list);
				return response;
	    	}catch (Exception e) {
	    		System.out.println(e);
	    		response.setMessage("Error");
				response.setStatus(false);
				response.setStatusCode(500);
				return response;
			}
	    }

	@GetMapping
    public CustomResponse findAllLanguages() {
    	return service.findAllLanguages();
    }

    @PostMapping(consumes = "application/json")
    public ResponseEntity<CustomResponse> create(@RequestBody Language cat) {
		
    	return service.save(cat);
    	    	
    }
	
}
