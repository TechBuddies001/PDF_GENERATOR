package com.trip.requset;

public class ReceivingRegistrationReceipt {
	private int tripticketId;
	private String nameofReceivingRegistrant;
	private String emailAddress;
	private String PhoneNumber;
	private String dateReceived;
	private String timeReceived;
	
	public int getTripticketId() {
		return tripticketId;
	}
	public void setTripticketId(int tripticketId) {
		this.tripticketId = tripticketId;
	}
	public String getNameofReceivingRegistrant() {
		return nameofReceivingRegistrant;
	}
	public void setNameofReceivingRegistrant(String nameofReceivingRegistrant) {
		this.nameofReceivingRegistrant = nameofReceivingRegistrant;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public String getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}
	public String getTimeReceived() {
		return timeReceived;
	}
	public void setTimeReceived(String timeReceived) {
		this.timeReceived = timeReceived;
	}

}
