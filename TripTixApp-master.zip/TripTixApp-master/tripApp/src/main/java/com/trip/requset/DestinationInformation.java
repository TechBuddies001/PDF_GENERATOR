package com.trip.requset;

public class DestinationInformation {

    private String destinationdate;
	private String destinationtime;
    private String destinationAddress;
    private String destinationCity;
    private String destinationState;
    private String destnationZip;
    
    
	public String getDestinationdate() {
		return destinationdate;
	}
	public void setDestinationdate(String destinationdate) {
		this.destinationdate = destinationdate;
	}
	public String getDestinationtime() {
		return destinationtime;
	}
	public void setDestinationtime(String destinationtime) {
		this.destinationtime = destinationtime;
	}
	public String getDestinationAddress() {
		return destinationAddress;
	}
	public void setDestinationAddress(String destinationAddress) {
		this.destinationAddress = destinationAddress;
	}
	public String getDestinationCity() {
		return destinationCity;
	}
	public void setDestinationCity(String destinationCity) {
		this.destinationCity = destinationCity;
	}
	public String getDestinationState() {
		return destinationState;
	}
	public void setDestinationState(String destinationState) {
		this.destinationState = destinationState;
	}
	public String getDestnationZip() {
		return destnationZip;
	}
	public void setDestnationZip(String destnationZip) {
		this.destnationZip = destnationZip;
	}
	public int getTripticketId() {
		return tripticketId;
	}
	public void setTripticketId(int tripticketId) {
		this.tripticketId = tripticketId;
	}
	private int tripticketId;
}

