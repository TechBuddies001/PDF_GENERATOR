package com.trip.requset;

import javax.validation.constraints.NotNull;

public class ChargeRequest {
	

	@NotNull
	private int amount; // cents

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
	
}
