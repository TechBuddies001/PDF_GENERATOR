package com.trip.requset;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModelProperty;

public class SubscriptionRequest {
   
	private int userId;
	
	private String amount;
	
	private String subscriptionType;
	
	@NotNull
	private String stripepaymentId;

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(String subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public String getStripepaymentId() {
		return stripepaymentId;
	}

	public void setStripepaymentId(String stripepaymentId) {
		this.stripepaymentId = stripepaymentId;
	}
	
}
