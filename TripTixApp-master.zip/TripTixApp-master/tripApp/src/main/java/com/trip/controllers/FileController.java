package com.trip.controllers;

import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.repo.UserRolesRepo;
import com.trip.requset.CustomResponse;
import com.trip.response.FileResponse;
import com.trip.response.UploadFileResponse;
import com.trip.response.UserProfileResponse;
import com.trip.services.FileStorageService;
import com.trip.services.StorageService;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
@RestController
@RequestMapping(path="/fileuplode")
public class FileController {
	private static final Logger logger = LoggerFactory.getLogger(FileController.class);

    @Autowired
    private FileStorageService fileStorageService;
    
    @Autowired
	private UserRepo userRepository;
    
    @Autowired
    UserRolesRepo rolesRepo;
    
//    @PostMapping("/uploadFile")
//    public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) {
//        String fileName = fileStorageService.storeFile(file);
//
//        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
//                .path("/downloadFile/")
//                .path(fileName)
//                .toUriString();
//
//        return new UploadFileResponse(fileName, fileDownloadUri,
//                file.getContentType(), file.getSize());
//    }
//
//    @PostMapping("/uploadMultipleFiles")
//    public List<UploadFileResponse> uploadMultipleFiles(@RequestParam("files") MultipartFile[] files) {
//        return Arrays.asList(files)
//                .stream()
//                .map(file -> uploadFile(file))
//                .collect(Collectors.toList());
//    }
//
//    @GetMapping("/downloadFile/{fileName:.+}")
//    public ResponseEntity<Resource> downloadFile(@PathVariable String fileName, HttpServletRequest request) {
//        // Load file as Resource
//        Resource resource = fileStorageService.loadFileAsResource(fileName);
//
//        // Try to determine file's content type
//        String contentType = null;
//        try {
//            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
//        } catch (IOException ex) {
//            logger.info("Could not determine file type.");
//        }
//
//        // Fallback to the default content type if type could not be determined
//        if(contentType == null) {
//            contentType = "application/octet-stream";
//        }
//
//        return ResponseEntity.ok()
//                .contentType(MediaType.parseMediaType(contentType))
//                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
//                .body(resource);
//    }
    
    //====================uplode static folder ========================//
    @RequestMapping(value = "/updateProfilepicture/{userId}", method = RequestMethod.POST)
    public ResponseEntity<CustomResponse> updateProfile(@RequestParam("file") MultipartFile file,@PathVariable int userId) throws Exception {
    	CustomResponse response = new CustomResponse();
    	Optional<Users> userpic = userRepository.findById(userId);
        
       if(userpic.isPresent()==true) {
    	   //
    	   File convFile = new File("src/main/resources/static/images/"+file.getOriginalFilename());
    	 //  File convFile = new File("https://mainetriptix.com/triptix/images/"+file.getOriginalFilename());
    	   convFile.createNewFile();
           FileOutputStream fos = new FileOutputStream(convFile);
          // Blob blob = new SerialBlob(file.getBytes());

           fos.write(file.getBytes());
           fos.close();
           System.out.println(convFile.getName());

           String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                   .path("/images/")
                   .path(convFile.getName())
                   .toUriString();
    	   userpic.get().setPhotoUrl(fileDownloadUri);
    	   userRepository.save(userpic.get());
    	   UploadFileResponse res =  	   new UploadFileResponse(convFile.getName(), fileDownloadUri,
                   file.getContentType(), file.getSize());
    	   
			response.setMessage("Success");
			response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response);
       }else {
    	   response.setMessage("Invalid Email/Password");
			response.setStatus(false);
			response.setStatusCode(200);
			return ResponseEntity.status(HttpStatus.OK).body(response);  
       }
        
       // filmRepository.save(new Film(convFile.getName(), blob));
    }
    //=================get profile image=========//
    @RequestMapping(value = "/getProfilepicture/{userId}", method = RequestMethod.GET)
    public ResponseEntity<CustomResponse> getProfile(@PathVariable int userId/*,Principal principal*/) throws Exception {
    //	String email =principal.getName();
    	//System.out.println("user name "+email);
    	UserProfileResponse pres = new UserProfileResponse();
    	CustomResponse response = new CustomResponse();
    	Optional<Users> userProfile = userRepository.findById(userId);
    	if(userProfile.isPresent()==true) {
    		pres.setProfileurl(userProfile.get().getPhotoUrl());
    		response.setMessage("Success");
			response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(pres);
			return ResponseEntity.status(HttpStatus.OK).body(response);
    		
    	}else {
    		response.setMessage("User id  not persent");
			response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(pres);
			return ResponseEntity.status(HttpStatus.OK).body(response);
    		
    	}
    	
		//return null;
    }
    
    @PostMapping(path="/upload/{userId}", consumes = MediaType.ALL_VALUE)
    public ResponseEntity<CustomResponse> uploadFile(@RequestPart(value = "file") MultipartFile file,@PathVariable int userId)
    {
    	CustomResponse response = new CustomResponse();
    	String fileUrl;
    	try {
    		Optional<Users> userpic = userRepository.findById(userId);
    	//	https://mainetriptix.com/triptix/images/
    	       if(userpic.isPresent()==true) {
    	    	 // fileUrl = "https://" + SecurityConstants.AWS_bucketName +".s3.amazonaws.com/" + file.getOriginalFilename();
    	    	   fileUrl = "https://"+"mainetriptix.com/"+"triptix/"+"images/"+file.getOriginalFilename();
    	    	   response.setMessage("Success");
    				response.setStatus(true);
    				response.setStatusCode(200);
    				response.setResponseObj(fileUrl);
    				

    				
    				
    				return ResponseEntity.status(HttpStatus.OK).body(response);
    	       }else {
    	    	  response.setMessage("user not exist");
   				response.setStatus(false);
   				response.setStatusCode(200);
   				response.setResponseObj("null");
   				

   				
   				
   				return ResponseEntity.status(HttpStatus.OK).body(response);
   	       }
    		//this.amazonS3ClientService.uploadFileToS3Bucket(file, true);
    		
			
    	} catch (Exception e) {
			response.setMessage("Error in uploading file: " +e.getLocalizedMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}
        
    }
    
    
}
