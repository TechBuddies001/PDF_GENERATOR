package com.trip.requset;

import io.swagger.annotations.ApiModelProperty;

public class UseraddStripeRequest {
	
private int userId;
private String email;
@ApiModelProperty(required = false, hidden = true)
private String cusId;

public int getUserId() {
	return userId;
}
public void setUserId(int userId) {
	this.userId = userId;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getCusId() {
	return cusId;
}
public void setCusId(String cusId) {
	this.cusId = cusId;
}
}
