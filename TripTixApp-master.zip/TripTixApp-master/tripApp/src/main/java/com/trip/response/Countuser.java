package com.trip.response;

public class Countuser {

	private int activeUsers;
	private int inactiveUsers;
	private int totalUsers;
	
	public int getActiveUsers() {
		return activeUsers;
	}
	public void setActiveUsers(int activeUsers) {
		this.activeUsers = activeUsers;
	}
	public int getInactiveUsers() {
		return inactiveUsers;
	}
	public void setInactiveUsers(int inactiveUsers) {
		this.inactiveUsers = inactiveUsers;
	}
	public int getTotalUsers() {
		return totalUsers;
	}
	public void setTotalUsers(int totalUsers) {
		this.totalUsers = totalUsers;
	}
}
