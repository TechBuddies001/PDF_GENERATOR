package com.trip.services;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.requset.CustomResponse;
import com.trip.requset.UserUpdateRequest;

@Service
public class UserUpdateService {
	@Autowired
	private UserRepo userRepository;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	public ResponseEntity<CustomResponse> updateUserdetail(UserUpdateRequest user) {
		CustomResponse response = new CustomResponse();
		int id = user.getUserId();
	    Optional<Users> userdedtails	=userRepository.findById(id);
	    Optional<Users> exist =userRepository.findByEmail(user.getEmail());
	       if(exist.isPresent()== true){
	    	   System.out.println("email matched");
	    	   response.setMessage("user email is duplicate ");
				response.setStatus(false);
				response.setResponseObj(null);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);  
	       }
	       if(userdedtails.isPresent()==true) {
	    	 userdedtails.get().setFirstname(user.getFirstname()); 
	  	     userdedtails.get().setLastName(user.getLastName());
	  	     userdedtails.get().setEmail(user.getEmail());
	  	     userdedtails.get().setAddress(user.getAddress());
	  	     userdedtails.get().setCity(user.getCity());
	  	     userdedtails.get().setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
	  	     userdedtails.get().setPinCode(user.getPinCode());
	  	     userdedtails.get().setState(user.getState()); 
	  	      userRepository.save( userdedtails.get());
	  	    response.setMessage("user updated succesfully ");
	  	    response.setStatusCode(200);
			response.setStatus(true);

			response.setResponseObj( userdedtails.get().getEmail());
			return ResponseEntity.status(HttpStatus.OK).body(response);
	       }
	       else {
	    	   response.setMessage("user not persent");
		  	    
				response.setStatus(false);

				response.setResponseObj(null);
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	       }
	}

	public Optional<Users> getUser(int userId) {
		
		return userRepository.findById(userId);
	}

	
}
