package com.trip.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.trip.models.TicketSubscriptionPayment;

@Repository
public interface TicketPaymentRepository extends JpaRepository<TicketSubscriptionPayment, Integer>{

}
