package com.trip.security;

public class SecurityConstants {

	public static final String ALLOWED_ORIGIN = "http://localhost:4200";
	//public static final String ALLOWED_ORIGIN = "http://ec2-3-95-217-205.compute-1.amazonaws.com";
	public static final String SECRET = "SecretKeyToGenJWTs";
    public static final long EXPIRATION_TIME = 86400000; //1day   300000;//5min
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
    public static final String SIGN_UP_URL = "/user";
    
    public static final String AWS_accessKey="AKIAWVLV43EVEXATF6C6";
    public static final String AWS_secretKey="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";
    public static final String AWS_bucketName="trip-media";
    
}
