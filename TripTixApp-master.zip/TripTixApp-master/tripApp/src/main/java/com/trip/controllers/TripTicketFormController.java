package com.trip.controllers;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import com.trip.exceptions.FileStorageException;

import com.trip.models.TripTicketform;
import com.trip.models.Users;
import com.trip.repo.TripformRepo;
import com.trip.repo.UserRepo;
import com.trip.requset.AddSignature;
import com.trip.requset.CustomResponse;
import com.trip.requset.DepartureInformation;
import com.trip.requset.DestinationInformation;
import com.trip.requset.PatientorRegistrantRequest;
import com.trip.requset.ProductDescription;
import com.trip.requset.ReceivingRegistrationReceipt;
import com.trip.requset.TripticketRequest;
import com.trip.requset.UpdeteMobRequest;
import com.trip.response.DestinationResponse;
import com.trip.response.DipartureListResponse;
import com.trip.response.ReceiptResponse;
import com.trip.response.RecevingPatient;
import com.trip.response.SubscriptionResponse;
import com.trip.response.TicketStatus;
import com.trip.response.TransferingRegistrant;
import com.trip.response.TripResponse;
import com.trip.response.UserDetaileResponse;
import com.trip.services.PDFGenerator;

import springfox.documentation.schema.Model;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
@RestController
@RequestMapping(path = "/tripticket")
public class TripTicketFormController {
	
	
	@Autowired
	TripformRepo triprepo;
	
	@Autowired
	private UserRepo userRepository;
	
	//===============form 1=========================================//
	@PostMapping(path = "/cretetransferingRegistrant",consumes = "application/json")
	public ResponseEntity<CustomResponse> transferingRegistrant(@RequestBody TripticketRequest tripform) {
		TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
		ticket.setLegalName(tripform.getLegalName());
		ticket.setRegistryIdentificationCardnumber(tripform.getRegistryIdentificationCardnumber());
		//ticket.setRegistryIdentificationCardnumber(tripform.getRegistryIdentificationCardnumber());
		ticket.setNameofRegistrationCertificateholder(tripform.getNameofRegistrationCertificateholder());
		ticket.setRegistrationCertificateNumber(tripform.getRegistrationCertificateNumber());
		ticket.setUserID(tripform.getUserId());
		ticket.setFormNo(1);
		ticket.setfStatus("Pending");
		TripTicketform form= triprepo.save(ticket);
		if(form !=null) {
			Optional<Users> user = userRepository.findById(tripform.getUserId());
			if(user.isPresent()== true) {
				int ticketcreatedbyUser =user.get().getTotelscreatedticketbyUser();
			   System.out.println("totalticket of user"+ticketcreatedbyUser);
				user.get().setTotelscreatedticketbyUser(ticketcreatedbyUser+1);
				//System.out.println(" PAYID "+paydetail.givingetStripepaymentId());
				userRepository.save(user.get());
	                }
			res.setTripTicketid(form.getId());
			res.setLegalName(form.getLegalName());
			    response.setMessage("trip ticket created successfully ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	//=====================form 2============================//
	@PostMapping(path = "/addPatientidentIficationumber",consumes = "application/json")
	public ResponseEntity<CustomResponse> addpatientidentificationumber(@RequestBody PatientorRegistrantRequest tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		String patientIdentiNumber = tripform.getPatientidentificationumberorMedicalCertificationNumber();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripTicketId());
		if(form.isPresent() == true) {
			if(patientIdentiNumber != null) {
				form.get().setFormNo(2);
				form.get().setfStatus("Pending");
				form.get().setPatientidentificationumberorMedicalCertificationNumber(tripform.getPatientidentificationumberorMedicalCertificationNumber());	
				triprepo.save(form.get());
				res.setTripTicketid(form.get().getId());
				res.setLegalName(form.get().getLegalName());
				    response.setMessage(" add patient identification successfully ");
			  	    response.setStatusCode(200);
					response.setStatus(true);
					response.setResponseObj(res);
					return ResponseEntity.status(HttpStatus.OK).body(response);
			}else{
				form.get().setFormNo(2);
				form.get().setfStatus("Pending");
				form.get().setReceivinglegalName(tripform.getRplegalName());
				form.get().setReceivingregistrationCertificateNumber(tripform.getRpregistrationCertificateNumber());
			    form.get().setReceivingnameofRegistrationCertificateholder(tripform.getRpnameofRegistrationCertificateholder());
		        //form.get().setReceivingregistrationCertificateNumber(tripform.getRpregistrationCertificateNumber());
		        form.get().setReceivingregistryIdentificationCardnumber(tripform.getRpregistryIdentificationCardnumber());
		        triprepo.save(form.get());
		        res.setTripTicketid(form.get().getId());
				res.setLegalName(form.get().getLegalName());
				    response.setMessage(" add patient identification successfully ");
			  	    response.setStatusCode(200);
					response.setStatus(true);
					response.setResponseObj(res);
					return ResponseEntity.status(HttpStatus.OK).body(response);
			}
			
			
			
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	//======================form 3===============================//
	@PostMapping(path = "/addProductdescription",consumes = "application/json")
	public ResponseEntity<CustomResponse> addproductDescription(@RequestBody ProductDescription tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripticketId());
		if(form.isPresent() == true) {
			//form.get().setPatientidentificationumberorMedicalCertificationNumber(tripform.getPatientidentificationumberorMedicalCertificationNumber());
			form.get().setFormNo(3);
			form.get().setfStatus("Pending");
			form.get().setDescriptionofProducts(tripform.getDescriptionofProducts());
			triprepo.save(form.get());
			res.setTripTicketid(form.get().getId());
			res.setLegalName(form.get().getLegalName());
			    response.setMessage("trip ticket created successfully ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	
	//==============================form no 4=======================//
	@PostMapping(path = "/addDepartureInformation",consumes = "application/json")
	public ResponseEntity<CustomResponse> addDepartureInformation(@RequestBody DepartureInformation tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripticketId());
		if(form.isPresent() == true) {
			form.get().setDepartureStartdate(tripform.getDepartureStartdate());
			form.get().setDepartureStarttime(tripform.getDepartureStarttime());
			form.get().setDepartureCity(tripform.getDepartureCity());
			form.get().setDepartureAddress(tripform.getDepartureAddress());
			form.get().setDepartureState(tripform.getDepartureState());
			form.get().setDepartureZip(tripform.getDepartureZip());
			form.get().setFormNo(4);
			form.get().setfStatus("Pending");
			triprepo.save(form.get());
			res.setTripTicketid(form.get().getId());
			res.setLegalName(form.get().getLegalName());
			    response.setMessage("trip ticket departure information added successfully ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	//=============================form number 5========================//
	@PostMapping(path = "/addDestination",consumes = "application/json")
	public ResponseEntity<CustomResponse> addDestination(@RequestBody DestinationInformation tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripticketId());
		if(form.isPresent() == true) {
			form.get().setDestinationdate(tripform.getDestinationdate());
			form.get().setDestinationtime(tripform.getDestinationtime());
			form.get().setDestinationCity(tripform.getDestinationCity());
			form.get().setDestinationAddress(tripform.getDestinationAddress());
			form.get().setDestinationState(tripform.getDestinationState());
			form.get().setDestnationZip(tripform.getDestnationZip());
			form.get().setFormNo(5);
			form.get().setfStatus("Pending");
			triprepo.save(form.get());
			res.setTripTicketid(form.get().getId());
			res.setLegalName(form.get().getLegalName());
			    response.setMessage("trip ticket Destination information added successfully ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}

	
	//=================form number 7==================//
	@PostMapping(path = "/addSignature",consumes = "application/json")
	public ResponseEntity<CustomResponse> addDigitalSignature(@RequestBody AddSignature tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripticketId());
		if(form.isPresent() == true) {
			form.get().setSignature(tripform.getDigitalSignature());
			form.get().setFormNo(7);
			form.get().setfStatus("Success");
			triprepo.save(form.get());
			res.setTripTicketid(form.get().getId());
			res.setLegalName(form.get().getLegalName());
			    response.setMessage("signature added successfully ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	  //=======================form 6 ========================//
	@PostMapping(path = "/addReceivingRegistration",consumes = "application/json")
	public ResponseEntity<CustomResponse> acknowledgmentofReceipt(@RequestBody ReceivingRegistrationReceipt tripform) {
		//TripTicketform ticket = new TripTicketform();
		CustomResponse response = new CustomResponse();
		TripResponse res =new TripResponse();
	
	
		Optional<TripTicketform> form= triprepo.findById(tripform.getTripticketId());
		if(form.isPresent() == true) {
			form.get().setNameofReceivingRegistrant(tripform.getNameofReceivingRegistrant());
			form.get().setEmailAddress(tripform.getEmailAddress());
			form.get().setDateReceived(tripform.getDateReceived());
			form.get().setTimeReceived(tripform.getTimeReceived());
			form.get().setPhoneNumber(tripform.getPhoneNumber());
			//form.get().setDestnationZip(tripform.getDestnationZip());
			form.get().setFormNo(6);
			form.get().setfStatus("Pending");
			triprepo.save(form.get());
			res.setTripTicketid(form.get().getId());
			res.setLegalName(form.get().getLegalName());
			    response.setMessage("trip ticket Receiving Registration Signature and Acknowledgment of Receipt succes  ");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response);
		}else {
			response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}
	
	
	
	
	//===============uplode signature form no seven=======================//
	@PostMapping("/uploadSignature")
	public ResponseEntity<CustomResponse>  uplaodSignature(@RequestParam("imageFile") MultipartFile file,@RequestParam("ticketId") int id) throws IOException {	
		System.out.println("Original Image Byte Size - " + file.getBytes().length);
	CustomResponse response = new CustomResponse();	
	TripResponse res =new TripResponse();
	// Normalize file name
    String fileName = StringUtils.cleanPath(file.getOriginalFilename());

    try {
        // Check if the file's name contains invalid characters
        if (fileName.contains("..")) {
            throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
        }
        Optional<TripTicketform> form= triprepo.findById(id);
        if(form.isPresent()==true) {
        byte[] imageArr = file.getBytes();
        form.get().setSignature(imageArr);
    	form.get().setFormNo(7);
		form.get().setfStatus("Success");
		triprepo.save(form.get());
		res.setTripTicketid(form.get().getId());
		res.setLegalName(form.get().getLegalName());
		    response.setMessage("signature added successfully ");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response);
       // triprepo.save(form.get());
        }else {
        	response.setMessage("Error some internal problumes");
	  	    response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(form);
			return ResponseEntity.status(HttpStatus.OK).body(response);	
        }
       
    } catch (IOException ex) {
        throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
    }
	
	}
	
	
	
	@GetMapping(path ="getTicketform/{tripTicketId}")
	public ResponseEntity<CustomResponse> getTicketFormDetail(@PathVariable("tripTicketId") int id) {
		Optional<TripTicketform> form= triprepo.findById(id);
		CustomResponse response = new CustomResponse();
		if(form.isPresent() == true) {
		response.setMessage("These are Ticket form details");
  	    response.setStatusCode(200);
		response.setStatus(true);
		response.setResponseObj(form);
		return ResponseEntity.status(HttpStatus.OK).body(response); 
		
	}else {
		response.setMessage("form not found");
  	    response.setStatusCode(404);
		response.setStatus(false);
		response.setResponseObj(form);
		return ResponseEntity.status(HttpStatus.OK).body(response);
		
	}
   }
	
	@GetMapping(path = "/getallTicket")
	public ResponseEntity<CustomResponse> getallTicket(@RequestParam int userId) {
		List<TripTicketform> ticket = triprepo.findByuserId(userId);
		System.out.println(" "+ticket.size());
		CustomResponse response = new CustomResponse();
		if(ticket.size() != 0) {
			List<TripTicketform> res = new ArrayList<TripTicketform>();
			for(int i=0;i<ticket.size();i++) {
				TripTicketform form = new TripTicketform();
				form.setLegalName(ticket.get(i).getLegalName());
				form.setDescriptionofProducts(ticket.get(i).getDescriptionofProducts());
				form.setEmailAddress(ticket.get(i).getEmailAddress());
				form.setNameofReceivingRegistrant(ticket.get(i).getNameofReceivingRegistrant());
				form.setId(ticket.get(i).getId());
				form.setUserID(ticket.get(i).getUserID());
				form.setDateReceived(ticket.get(i).getDateReceived());
				form.setDepartureAddress(ticket.get(i).getDepartureAddress());
				form.setDepartureCity(ticket.get(i).getDepartureCity());
				form.setDepartureStartdate(ticket.get(i).getDepartureStartdate());
				form.setDepartureStarttime(ticket.get(i).getDepartureStarttime());
				form.setDepartureState(ticket.get(i).getDepartureState());
				form.setDepartureZip(ticket.get(i).getDepartureZip());
				form.setDestinationAddress(ticket.get(i).getDestinationAddress());
				form.setDestinationCity(ticket.get(i).getDestinationCity());
				form.setDestinationdate(ticket.get(i).getDestinationdate());
				form.setDestinationtime(ticket.get(i).getDestinationtime());
				form.setDestnationZip(ticket.get(i).getDestnationZip());
				form.setDestinationState(ticket.get(i).getDestinationState());
				form.setTimeReceived(ticket.get(i).getTimeReceived());
				form.setPhoneNumber(ticket.get(i).getPhoneNumber());
			 //	form.setDigitalSignature(ticket.get(i).getDigitalSignature());
				form.setRegistrationCertificateNumber(ticket.get(i).getRegistrationCertificateNumber());
		        form.setNameofRegistrationCertificateholder(ticket.get(i).getNameofRegistrationCertificateholder());
		        form.setPatientidentificationumberorMedicalCertificationNumber(ticket.get(i).getPatientidentificationumberorMedicalCertificationNumber());
			    form.setRegistryIdentificationCardnumber(ticket.get(i).getRegistryIdentificationCardnumber());
		        form.setFormNo(ticket.get(i).getFormNo());
		        form.setfStatus(ticket.get(i).getfStatus());
			    res.add(form);	
			}
			response.setMessage("These are Ticket form details");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		}else {
			response.setMessage("user id not found");
	  	    response.setStatusCode(404);
			response.setStatus(false);
			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
		
		
	}
	
	@GetMapping(path = "/getformStatus")
	public ResponseEntity<CustomResponse> getformStatus(@RequestParam int userId){
		String fStatus = "Pending";
		//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
		List<TripTicketform> ticket = triprepo.findStatusByuserId(userId,fStatus);
		System.out.println(" "+ticket.size());
		CustomResponse response = new CustomResponse();
		List<TicketStatus> tiketstatus = new ArrayList<TicketStatus>();
		
		if(ticket.size() != 0) {
			
			for(int i=0;i<ticket.size();i++) {
				TicketStatus status = new TicketStatus();
				status.setTicketId(ticket.get(i).getId());
				status.setCompletedformNo(ticket.get(i).getFormNo());
				status.setFormStatus(ticket.get(i).getfStatus());
				status.setUserId(ticket.get(i).getUserID());
				tiketstatus.add(status);
			}
			
			response.setMessage("Ticket Form is Pending please complete it.");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(tiketstatus);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}else {
			response.setMessage("No Pending Ticket form Please fillup New Ticket Form");
	  	    response.setStatusCode(200);
			response.setStatus(false);
			response.setResponseObj(tiketstatus);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}
		
	
}
	@GetMapping(path = "/getdepartureList")
	public ResponseEntity<CustomResponse> getdeparturlist(@RequestParam int userId){
		

		//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
		List<TripTicketform> ticket = triprepo.getDepartureList(userId);
		System.out.println(" dep "+ticket);
		System.out.println(" "+ticket.size());
		CustomResponse response = new CustomResponse();
		List<DipartureListResponse> tiketstatus = new ArrayList<DipartureListResponse>();
		
		if(ticket.size() != 0) {
			for(int i=0;i<ticket.size();i++) {
				DipartureListResponse status = new DipartureListResponse();

		       status.setDepartureAddress(ticket.get(i).getDepartureAddress());
		       System.out.println(" "+ticket.get(i).getDepartureAddress());
				status.setDepartureCity(ticket.get(i).getDepartureCity());
				status.setDepartureState(ticket.get(i).getDepartureState());
				status.setDepartureZip(ticket.get(i).getDepartureZip());
				tiketstatus.add(status);
			}
			
			response.setMessage("Departure details");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(tiketstatus);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}else {
			response.setMessage("Departure detail not found");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(tiketstatus);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}
		
	
}
	
	
	//=================================================//
	
	@GetMapping(path = "/getdestinationList")
	public ResponseEntity<CustomResponse> getdestinationlist(@RequestParam int userId){
		


		//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
		List<TripTicketform> ticket = triprepo.getDepartureList(userId);
		System.out.println(" dep "+ticket);
		System.out.println(" "+ticket.size());
		CustomResponse response = new CustomResponse();
		List<DestinationResponse> res = new ArrayList<DestinationResponse>();

		if(ticket.size() != 0) {

			for(int i=0;i<ticket.size();i++) {
				DestinationResponse status = new DestinationResponse();
		       status.setDestinationAddress(ticket.get(i).getDestinationAddress());
		       System.out.println(" "+ticket.get(i).getDestinationAddress());
				status.setDestinationCity(ticket.get(i).getDestinationCity());
				status.setDestinationState(ticket.get(i).getDestinationState());
				status.setDestnationZip(ticket.get(i).getDestnationZip());
				res.add(status);
				//System.out.println("t"+tiketstatus.indexOf(arg0).toString());
			}
			
			response.setMessage("Destination details");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}else {
			response.setMessage("Destination detail not found");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}
		
	
}
	
	@GetMapping(path = "/getSubscriptionStatus")
	public ResponseEntity<CustomResponse> getSubscriptionStatus(@RequestParam int userId) throws ParseException{
		CustomResponse response = new CustomResponse();
		SubscriptionResponse subsDetails= new SubscriptionResponse();
		int countTicket =triprepo.countcreatedticket(userId);
		if(countTicket>9) {
			subsDetails.setFreeSubsIsvalid(false);
		}else {
			subsDetails.setFreeSubsIsvalid(true);
		}
		System.out.println("total created ticket "+countTicket);
		
		//===================today Date=====================//
		Calendar cal = Calendar.getInstance();
	    SimpleDateFormat dateOnly = new SimpleDateFormat("dd/MM/yyyy");
	    System.out.println(""+dateOnly.format(cal.getTime()));
	    
	    String todayDate =dateOnly.format(cal.getTime());
	    System.out.println("today date"+ todayDate);
	    String sDate1=todayDate;  
	    Date today=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);  
	    System.out.println(sDate1+"\t"+today);  
		
	    
		//======================================================//
		
		Optional<Users> user = userRepository.findById(userId);
		
    	if(user.isPresent()== true) {
			
		    int remainingTick = user.get().getTotalTicket()-user.get().getTotelscreatedticketbyUser();
			int totTicket =user.get().getTotalTicket();
			System.out.println("remainingTick "+remainingTick+" totalTick  "+totTicket);
			
			
			
		    if(user.get().getSubsExpDate() !=null) {
		    	Date subsexpdate=new SimpleDateFormat("dd/MM/yyyy").parse(user.get().getSubsExpDate());  
			    System.out.println(sDate1+"\t"+subsexpdate); 
				if(today.after(subsexpdate)) {
					subsDetails.setSubsIsvalid(false);
				}
			}
		    
		    if(totTicket == user.get().getTotelscreatedticketbyUser() ||remainingTick < 0 ) {
				subsDetails.setSubsIsvalid(false);
			}else {
				subsDetails.setSubsIsvalid(true);
			}			
	//=======================================================================//		
			subsDetails.setRemainingTicket(remainingTick);
			subsDetails.setTotalsubsTicket(totTicket);
			subsDetails.setSubsType(user.get().getSubsType());
			subsDetails.setSubExpaireDate(user.get().getSubsExpDate());
			subsDetails.setSubscriptionDate(user.get().getSubsDate());
			subsDetails.setTotalecretedTicketbyuser(user.get().getTotelscreatedticketbyUser());
		response.setMessage("subscription details");
  	    response.setStatusCode(200);
		response.setStatus(true);
		response.setResponseObj(subsDetails);
		return ResponseEntity.status(HttpStatus.OK).body(response); 
	
    
		}else {
			response.setMessage("UserId not found");
	  	    response.setStatusCode(200);
			response.setStatus(false);
			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}
		
	
}
	//=======================getTransfering===============================//
	@GetMapping(path = "/getTransfRegistenList")
	public ResponseEntity<CustomResponse> getTransfRegistenList(@RequestParam int userId){
		//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
		List<TripTicketform> ticket = triprepo.getDepartureList(userId);
		System.out.println(" dep "+ticket);
		System.out.println(" "+ticket.size());
		CustomResponse response = new CustomResponse();
		List<TransferingRegistrant> res = new ArrayList<TransferingRegistrant>();

		if(ticket.size() != 0) {

			for(int i=0;i<ticket.size();i++) {
				TransferingRegistrant status = new TransferingRegistrant();
		       status.settLegalName(ticket.get(i).getLegalName());
		       System.out.println(" "+ticket.get(i).getDestinationAddress());
				status.settCardNumber(ticket.get(i).getRegistryIdentificationCardnumber());
				status.settLegalNameifApplicable(ticket.get(i).getNameofRegistrationCertificateholder());
				status.settRegistrationCertificateNuberifApplicable(ticket.get(i).getRegistrationCertificateNumber());
				res.add(status);
				//System.out.println("t"+tiketstatus.indexOf(arg0).toString());
			}
			
			response.setMessage("transfering details");
	  	    response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(res);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}else {
			response.setMessage("transfering detail not found");
	  	    response.setStatusCode(400);
			response.setStatus(false);
			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.OK).body(response); 
		
		}
		
	
}
	//=======================getReciveing ===============================//
		@GetMapping(path = "/getreciveingPatientList")
		public ResponseEntity<CustomResponse> getreciveingPatientList(@RequestParam int userId){
			//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
			List<TripTicketform> ticket = triprepo.getDepartureList(userId);
			System.out.println(" dep "+ticket);
			System.out.println(" "+ticket.size());
			CustomResponse response = new CustomResponse();
			List<RecevingPatient> res = new ArrayList<RecevingPatient>();

			if(ticket.size() != 0) {

				for(int i=0;i<ticket.size();i++) {
					RecevingPatient status = new RecevingPatient();
			       status.setRecevingPatientmedicalcNumber(ticket.get(i).getReceivingregistrationCertificateNumber());
			     System.out.println(" patient "+ticket.get(i).getReceivingregistrationCertificateNumber());
					
					res.add(status);
					//System.out.println("t"+tiketstatus.indexOf(arg0).toString());
				}
				
				response.setMessage("receving Patient details");
		  	    response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(res);
				return ResponseEntity.status(HttpStatus.OK).body(response); 
			
			}else {
				response.setMessage("reciveing patient detail not found");
		  	    response.setStatusCode(400);
				response.setStatus(false);
				response.setResponseObj(null);
				return ResponseEntity.status(HttpStatus.OK).body(response); 
			
			}
		}
		//=======================getProduct===============================//
				@GetMapping(path = "/getproductList")
				public ResponseEntity<CustomResponse> getproductList(@RequestParam int userId){
					//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
					List<TripTicketform> ticket = triprepo.getDepartureList(userId);
					System.out.println(" dep "+ticket);
					System.out.println(" "+ticket.size());
					CustomResponse response = new CustomResponse();
					List<ProductDescription> res = new ArrayList<ProductDescription>();

					if(ticket.size() != 0) {

						for(int i=0;i<ticket.size();i++) {
							ProductDescription status = new ProductDescription();
					       status.setDescriptionofProducts(ticket.get(i).getDescriptionofProducts());
					      // System.out.println(" patient "+ticket.get(i).getReceivingregistrationCertificateNumber());
							res.add(status);
							//System.out.println("t"+tiketstatus.indexOf(arg0).toString());
						}
						
						response.setMessage("product  details");
				  	    response.setStatusCode(200);
						response.setStatus(true);
						response.setResponseObj(res);
						return ResponseEntity.status(HttpStatus.OK).body(response); 
					
					}else {
						response.setMessage("reciveing patient detail not found");
				  	    response.setStatusCode(400);
						response.setStatus(false);
						response.setResponseObj(null);
						return ResponseEntity.status(HttpStatus.OK).body(response); 
					
					}
				}
				
				
				//=======================getReciept===============================//
				@GetMapping(path = "/getacknowledgmentRecieptList")
				public ResponseEntity<CustomResponse> getacknowledgmentRecieptList(@RequestParam int userId){
					//TripTicketform	ticketformstatus = triprepo.getformStatus(userId,fStatus);
					
					List<TripTicketform> ticket = triprepo.getDepartureList(userId);
					System.out.println(" dep "+ticket);
					System.out.println(" "+ticket.size());
					CustomResponse response = new CustomResponse();
					List<ReceiptResponse> res = new ArrayList<ReceiptResponse>();

					if(ticket.size() != 0) {

						for(int i=0;i<ticket.size();i++) {
							ReceiptResponse status = new ReceiptResponse();
					       status.setRprintedName(ticket.get(i).getNameofReceivingRegistrant());
					       status.setrPhonNumber(ticket.get(i).getPhoneNumber());
					       status.setrEmail(ticket.get(i).getEmailAddress());
					      // System.out.println(" patient "+ticket.get(i).getReceivingregistrationCertificateNumber());
							res.add(status);
							//System.out.println("t"+tiketstatus.indexOf(arg0).toString());
						}
						
						response.setMessage("Reciving details");
				  	    response.setStatusCode(200);
						response.setStatus(true);
						response.setResponseObj(res);
						return ResponseEntity.status(HttpStatus.OK).body(response); 
					
					}else {
						response.setMessage("reciveing  detail not found");
				  	    response.setStatusCode(400);
						response.setStatus(false);
						response.setResponseObj(null);
						return ResponseEntity.status(HttpStatus.OK).body(response); 
					
					}
				}
}