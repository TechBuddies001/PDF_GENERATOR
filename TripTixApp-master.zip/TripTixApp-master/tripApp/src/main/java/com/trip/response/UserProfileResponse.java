package com.trip.response;

public class UserProfileResponse {
private String Profileurl;

public String getProfileurl() {
	return Profileurl;
}

public void setProfileurl(String profileurl) {
	Profileurl = profileurl;
}

}
