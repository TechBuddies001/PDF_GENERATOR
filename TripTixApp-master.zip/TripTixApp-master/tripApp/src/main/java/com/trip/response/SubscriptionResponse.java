package com.trip.response;

public class SubscriptionResponse {
	private  String subsType;
	private int totalsubsTicket;
	private int totalecretedTicketbyuser;
	private int remainingTicket;
	private String subscriptionDate;
	private String subExpaireDate;
	private boolean subsIsvalid;
	private boolean freeSubsIsvalid;
	
	public boolean isFreeSubsIsvalid() {
		return freeSubsIsvalid;
	}
	public void setFreeSubsIsvalid(boolean freeSubsIsvalid) {
		this.freeSubsIsvalid = freeSubsIsvalid;
	}
	public String getSubsType() {
		return subsType;
	}
	public void setSubsType(String subsType) {
		this.subsType = subsType;
	}
	public int getTotalsubsTicket() {
		return totalsubsTicket;
	}
	public void setTotalsubsTicket(int totalsubsTicket) {
		this.totalsubsTicket = totalsubsTicket;
	}
	public int getRemainingTicket() {
		return remainingTicket;
	}
	public void setRemainingTicket(int remainingTicket) {
		this.remainingTicket = remainingTicket;
	}
	public String getSubscriptionDate() {
		return subscriptionDate;
	}
	public void setSubscriptionDate(String subscriptionDate) {
		this.subscriptionDate = subscriptionDate;
	}
	public String getSubExpaireDate() {
		return subExpaireDate;
	}
	public void setSubExpaireDate(String subExpaireDate) {
		this.subExpaireDate = subExpaireDate;
	}
	public boolean isSubsIsvalid() {
		return subsIsvalid;
	}
	public void setSubsIsvalid(boolean subsIsvalid) {
		this.subsIsvalid = subsIsvalid;
	}
	public int getTotalecretedTicketbyuser() {
		return totalecretedTicketbyuser;
	}
	public void setTotalecretedTicketbyuser(int totalecretedTicket) {
		this.totalecretedTicketbyuser = totalecretedTicket;
	}
	

}
