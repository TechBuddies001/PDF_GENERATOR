package com.trip.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


import com.trip.models.Users;

@RepositoryRestResource(path = "/users")
//@RestResource(exported = false)
public interface UserRepo extends PagingAndSortingRepository<Users, Integer> {

	public Users findByEmailIgnoreCase(String email);
	
	Boolean existsByEmail(String email);
	 Optional<Users> findByEmail(String email);
	 
	 Optional<Users> findByResetToken(String resetToken);
	// OR
//	public List<Users> findByFnameOrLnameIgnoreCase(String fname, String lname);

//	@Query(value="SELECT password FROM users WHERE lower(email) =':emailId'", nativeQuery = true)
//	public String getUserPassword(@Param("emailId") String emailId);
	
	
	@Query(value="SELECT * FROM users u WHERE u.user_rollid NOT IN(SELECT id FROM user_roles WHERE title='Admin')", nativeQuery = true)
	public Page<Users> findAllUsersByPage(Pageable page);
	
	@Query(value="SELECT Count(*) FROM users WHERE time_stamp > ?1 And user_role_id NOT IN(SELECT id FROM USER_ROLES WHERE title = 'Admin')", nativeQuery = true)
	public int findNewUsersCount(String lastweekdate);
	
	@Query(value="SELECT * FROM users WHERE is_active =1", nativeQuery = true)
	public List<Users> findAllActiveUsers();
	
	//Search query
	@Query(value="SELECT * FROM users u WHERE u.user_role_id NOT IN(SELECT id FROM USER_ROLES WHERE title = 'Admin') And (u.name like %:keyword% or email like %:keyword% )", nativeQuery = true)
	public List<Users> searchUserBykeyword(@Param("keyword") String keyword);

	@Query(value = "SELECT Count(*) FROM users WHERE user_rollid NOT IN(SELECT id FROM user_roles WHERE title = 'Admin')",nativeQuery = true)
	public int findAllUserCount();

	@Query(value =  "SELECT * FROM users WHERE user_rollid NOT IN(SELECT id FROM user_roles WHERE title = 'Admin')",nativeQuery = true)
	public List<Users> findAllUsers();

	@Query(value="SELECT Count(*) FROM users WHERE is_active =1 And user_rollid NOT IN(SELECT id FROM user_roles WHERE title = 'Admin')", nativeQuery = true)
	public int findAllActiveUserCount();
	
	
	@Query(value="SELECT Count(*) FROM users WHERE is_active =0 And user_rollid NOT IN(SELECT id FROM user_roles WHERE title = 'Admin')", nativeQuery = true)
	public int countAllInActiveUser();

	Optional<Users> findByMobileNo(String mobile_no);

}
