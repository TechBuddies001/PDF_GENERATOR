package com.trip.requset;

import javax.validation.constraints.Pattern;

public class UserDTO {
	private int userId;
	private String firstname, lastName, address;
	private String city, state, pinCode;
	@Pattern(regexp = "(^$|[0-9]{10})")
	private String mobileNo;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPinCode() {
		return pinCode;
	}
	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	
	public UserDTO() {
		super();
	}
	public UserDTO(int userId, String firstname, String lastName, String address, String city, String state,
			String pinCode, @Pattern(regexp = "(^$|[0-9]{10})") String mobileNo) {
		super();
		this.userId = userId;
		this.firstname = firstname;
		this.lastName = lastName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pinCode = pinCode;
		this.mobileNo = mobileNo;
	}
	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", firstname=" + firstname + ", lastName=" + lastName + ", address="
				+ address + ", city=" + city + ", state=" + state + ", pinCode=" + pinCode + ", mobileNo=" + mobileNo
				+ "]";
	}

}
