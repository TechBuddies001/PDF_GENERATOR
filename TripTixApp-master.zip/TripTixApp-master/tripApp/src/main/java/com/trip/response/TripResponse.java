package com.trip.response;

public class TripResponse {
	private int tripTicketid;
	private String legalName;
	
	public int getTripTicketid() {
		return tripTicketid;
	}
	public void setTripTicketid(int tripTicketid) {
		this.tripTicketid = tripTicketid;
	}
	public String getLegalName() {
		return legalName;
	}
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

}
