package com.trip.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.trip.models.UserRoles;
import com.trip.models.Users;
import com.trip.repo.UserRepo;
import com.trip.repo.UserRolesRepo;
import com.trip.requset.CustomResponse;
import com.trip.requset.LogInwithMobileRequest;
import com.trip.requset.LoginCred;
import com.trip.requset.MobileSignUp;
import com.trip.requset.UpdeteMobRequest;
import com.trip.requset.UserUpdateRequest;
import com.trip.response.UserResponse;
import com.trip.security.JwtTokenUtil;
import com.trip.services.OtpService;
import com.trip.services.UserUpdateService;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@RestController
@RequestMapping("/otp")
public class MobileLoginContoller {
//==============server credential========================//
	private final static String ACCOUNT_SID = "AC33ab651cc2b2fc21a76b4806091cc9f9";
	private final static String AUTH_TOKEN = "60f8ebc7abc30a57f89553b70072f67e";
	private final static String from = "+12055518949";
//===========testing credential=========================//
//private final static String ACCOUNT_SID = "ACe745c5e95557a53ec4fa5be3d57a8852";
//private final static String AUTH_TOKEN =   "fe5a26d77c98a74918bf8c6034419172";

//private final static String from = "+14152374386";

	@Autowired
	private UserRepo userRepository;

	@Autowired
	OtpService otpService;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	UserRolesRepo rolesRepo;

	@Autowired
	UserUpdateService servic;

	@Autowired
	ObjectMapper mapper;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@PostMapping(path = "/signupuser", consumes = "application/json")
	public ResponseEntity<CustomResponse> createuser(@RequestBody MobileSignUp signup) {

		UserRoles roles = new UserRoles();
		Users userotp = new Users();

		CustomResponse response = new CustomResponse();
		String mobile = signup.getMobNumber();
		String caregiver = signup.getCaregiverNumber();
		System.out.println(" care code " + caregiver);
		// String mobilecode ="+91"+""+mobile;
		System.out.println(" mobile code " + mobile);

		// ====================login=======================//
		if (caregiver == null) {
			Optional<Users> usermob = userRepository.findByMobileNo(mobile);
			if (usermob.isPresent() == true) {

				int otp = otpService.generateOTP(mobile);
				String genratedotp = String.valueOf(otp);
				System.out.println(" one time pass " + otp);
				usermob.get().setOtp(bCryptPasswordEncoder.encode(genratedotp));
				userRepository.save(usermob.get());
				// ============send otp ===========//
				Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
				Message messagemob = Message.creator(new PhoneNumber(mobile), // to
						new PhoneNumber(from), // from
						"TripTix Account Login OTP is :" + otp).create();
                System.out.println(messagemob);
                if(usermob.get().getStripepaymentId()== null) {
                	signup.setPaymentStatus(false);
                }
                else {
                	signup.setPaymentStatus(true);
                }
				String jwt = jwtTokenUtil.generateToken(usermob.get().getMobileNo());
				signup.setToken(jwt);
				signup.setUserId(usermob.get().getId());
				signup.setMobNumber(usermob.get().getMobileNo());
				signup.setNewReg(false);
				response.setMessage("login success  ");
				response.setResponseObj(signup);
				response.setStatusCode(200);
				response.setStatus(true);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response.setMessage("Mobile number not Registerd plese  Go for Signup");
				response.setStatus(false);
				response.setStatusCode(400);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		}
//=========================signup====================================//
		Optional<Users> user = userRepository.findByMobileNo(mobile);
		if (user.isPresent() == true) {

			int otp = otpService.generateOTP(mobile);
			String genratedotp = String.valueOf(otp);

			System.out.println(" one time pass " + otp);
			user.get().setOtp(bCryptPasswordEncoder.encode(genratedotp));
			userRepository.save(user.get());

			// ============send otp ===========//
			Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
			Message messagemob = Message.creator(new PhoneNumber(mobile), // to
					new PhoneNumber(from), // from
					"TripTix Account Login OTP is " + otp).create();

			System.out.println(messagemob);

			// ===================================//
			String jwt = jwtTokenUtil.generateToken(user.get().getMobileNo());
			signup.setToken(jwt);
			signup.setUserId(user.get().getId());
			signup.setMobNumber(user.get().getMobileNo());
			signup.setNewReg(false);
			response.setMessage("OTP SEND YOUR registerd number ,your number is  already registered");
			response.setResponseObj(signup);
			response.setStatusCode(200);
			response.setStatus(true);
			return ResponseEntity.status(HttpStatus.OK).body(response);

		} else {

			int otp = otpService.generateOTP(mobile);
			String genratedotp = String.valueOf(otp);
			System.out.println(" one time pass " + otp);
			userotp.setOtp(bCryptPasswordEncoder.encode(genratedotp));
			userotp.setMobileNo(mobile);
			userotp.setCaregiverNumber(signup.getCaregiverNumber());
			Users users = userRepository.save(userotp);
			if (users != null) {
				int id = users.getId();
				Optional<Users> userrole = userRepository.findById(id);
				if (userrole.isPresent() == true) {
					roles.setRole_id(userrole.get().getId());
					roles.setTitle("User");
					rolesRepo.save(roles);

				}

			}
			/// ==============================================otp==============================//
			Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
			Message message = Message.creator(new PhoneNumber(mobile), // to
					new PhoneNumber(from), // from
					"TripTix Account Login OTP is : " + otp + " ").create();
			System.out.println(message);
			// =========================//
			signup.setUserId(users.getId());
			signup.setMobNumber(users.getMobileNo());
			signup.setNewReg(true);
			String jwt = jwtTokenUtil.generateToken(users.getMobileNo());
			signup.setToken(jwt);
			response.setMessage("Registration successfully ");
			response.setStatusCode(200);
			response.setResponseObj(signup);
			response.setStatus(true);
			return ResponseEntity.status(HttpStatus.OK).body(response);
		}
	}

	@PostMapping(path = "/updateusersdetails", consumes = "application/json")
	public ResponseEntity<CustomResponse> updateUserdetails(@RequestBody UserUpdateRequest user) {

		return servic.updateUserdetail(user);

	}

	@PostMapping(path = "/updatemobile", consumes = "application/json")
	public ResponseEntity<CustomResponse> updateMobile(@RequestBody UpdeteMobRequest user) {
		CustomResponse response = new CustomResponse();
		int id = user.getUserId();
		Optional<Users> userdedtails = userRepository.findById(id);
		Optional<Users> usermob = userRepository.findByMobileNo(user.getMobileNumber());
		if (usermob.isPresent() == true) {
			response.setMessage("user mobile number registered ");
			response.setStatus(false);
			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
		}
		if (userdedtails.isPresent() == true) {
			userdedtails.get().setMobileNo(user.getMobileNumber());
			userRepository.save(userdedtails.get());
			response.setMessage("user mobile number updated succesfully ");
			response.setStatusCode(200);
			response.setStatus(true);
			response.setResponseObj(userdedtails.get().getEmail());
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} else {
			response.setMessage("user not persent");

			response.setStatus(false);

			response.setResponseObj(null);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
		}

	}

	@PostMapping(path = "/loginWithmobile", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomResponse> mobLogin(@RequestBody LogInwithMobileRequest loginObj) {

		CustomResponse response = new CustomResponse();
		UserResponse userdetails = new UserResponse();
		try {

			String otp = "";
			Optional<Users> user = servic.getUser(loginObj.getUserId());
			if (user.isPresent() == true) {

				otp = user.get().getOtp();

				// if (loginObj.getPassword().equalsIgnoreCase(passswd)) {
				if (bCryptPasswordEncoder.matches(loginObj.getOtp(), otp)) {
					Optional<UserRoles> role = rolesRepo.findById(user.get().getId());
					if (role.isPresent() == true) {
						userdetails.setRollAs(role.get().getTitle());
					}
					 if(user.get().getStripepaymentId()== null) {
						 userdetails.setPaymentStatus(false);
		                }
		                else {
		                	userdetails.setPaymentStatus(true);
		                }
					userdetails.setUserId(user.get().getId());
					userdetails.setName(user.get().getName());
					userdetails.setEmail(user.get().getEmail());
					userdetails.setActive(user.get().isActive());
					userdetails.setPhotoUrl(user.get().getPhotoUrl());
					response.setMessage("login Success");
					response.setStatusCode(200);
					response.setStatus(true);
					ObjectNode object = mapper.createObjectNode();
					object.put("token", jwtTokenUtil.generateToken(user.get().getMobileNo()));
					object.putPOJO("User", userdetails);
					response.setResponseObj(object);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				} else {
					response.setMessage("Invalid mobile/otp");
					response.setStatus(false);
					response.setStatusCode(200);
					return ResponseEntity.status(HttpStatus.OK).body(response);
				}

			} else {
				response.setMessage("userId not exist plese Go for Signup");
				response.setStatus(false);
				response.setStatusCode(400);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}

		} catch (Exception e) {
			response.setMessage("Error :" + e.getLocalizedMessage());
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}

	}

	@GetMapping(path = "/getLoginOtp")
	public ResponseEntity<CustomResponse> getLoginOtp(@RequestParam String Mobinumber) {

		CustomResponse response = new CustomResponse();
		UserResponse userdetails = new UserResponse();
		MobileSignUp usersignup = new MobileSignUp();
		UserRoles roles = new UserRoles();
		Users userotp = new Users();
		try {

			Optional<Users> user = userRepository.findByMobileNo(Mobinumber);
			if (user.isPresent() == true) {
				int otp = otpService.generateOTP(Mobinumber);
				String genratedotp = String.valueOf(otp);
				System.out.println(" one time pass " + otp);
				user.get().setOtp(bCryptPasswordEncoder.encode(genratedotp));
				userRepository.save(user.get());
				// ============send otp ===========//

				Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
				Message message = Message.creator(new com.twilio.type.PhoneNumber(Mobinumber),
						new com.twilio.type.PhoneNumber(from), "TripTix Account Login OTP is : " + otp).create();

				System.out.println(message.getSid());

				// ===================================//
				userdetails.setUserId(user.get().getId());
				userdetails.setName(user.get().getName());
				userdetails.setEmail(user.get().getEmail());
				userdetails.setActive(user.get().isActive());
				userdetails.setPhotoUrl(user.get().getPhotoUrl());
				response.setMessage("Otp send your mobile number " + Mobinumber + " ");
				response.setStatusCode(200);
				response.setStatus(true);
				response.setResponseObj(userdetails);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {

				int otp = otpService.generateOTP(Mobinumber);
				String genratedotp = String.valueOf(otp);
				System.out.println(" one time pass " + otp);
				userotp.setOtp(bCryptPasswordEncoder.encode(genratedotp));
				userotp.setMobileNo(Mobinumber);
				Users users = userRepository.save(userotp);
				if (users != null) {
					int id = users.getId();
					Optional<Users> userrole = userRepository.findById(id);
					if (userrole.isPresent() == true) {
						roles.setRole_id(userrole.get().getId());
						roles.setTitle("User");
						rolesRepo.save(roles);

					}

				}
				 if(users.getStripepaymentId()== null) {
					 usersignup.setPaymentStatus(false);
	                }
	                else {
	                	usersignup.setPaymentStatus(true);
	                }
				/// ==============================================otp==============================//
				Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
				Message message = Message.creator(new PhoneNumber(Mobinumber), // to
						new PhoneNumber(from), // from
						"TripTix Account Login OTP is : " + otp + " ").create();
				System.out.println(message);
				// =========================//
				usersignup.setUserId(users.getId());
				usersignup.setMobNumber(users.getMobileNo());
				usersignup.setNewReg(true);
				String jwt = jwtTokenUtil.generateToken(users.getMobileNo());
				usersignup.setToken(jwt);
				
				response.setMessage("Registration success and otp send your mobile number ");
				response.setStatusCode(200);
				response.setResponseObj(usersignup);
				response.setStatus(true);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}

		} catch (Exception e) {
			// response.setMessage("Error :" + e.getLocalizedMessage());
			response.setMessage("Error :" + e);
			response.setStatus(false);
			response.setStatusCode(500);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
		}

	}
}
