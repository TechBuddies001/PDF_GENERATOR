package com.trip.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.trip.models.Language;

@RepositoryRestResource
//@RestResource(exported = false)
public interface LanguageRepo extends JpaRepository<Language, Integer> {

	//Search all languages
	@Query(value="SELECT * FROM language WHERE name like %:keyword%", nativeQuery = true)
	List<Language> searchBykeyword(@Param("keyword")String key);

	
	// OR
//	public List<Language> findByFnameOrLnameIgnoreCase(String fname, String lname);

//	@Query(value="SELECT Count(*) FROM Language WHERE time_stamp > ?1", nativeQuery = true)
//	public int findNewUsersCount(String lastweekdate);
	
//	@Query(value="SELECT Count(*) FROM Language WHERE organised_by_id = ?1", nativeQuery = true)
//	public int findTotalEventsByArtist(int artistId);

}
