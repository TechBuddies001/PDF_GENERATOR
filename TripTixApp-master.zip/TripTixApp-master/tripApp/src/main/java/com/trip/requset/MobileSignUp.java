package com.trip.requset;

import javax.persistence.Version;

import io.swagger.annotations.ApiModelProperty;

public class MobileSignUp {

@ApiModelProperty(required = false, hidden = true)
@Version
private int userId;

@ApiModelProperty(required = false, hidden = true)
@Version
private boolean newReg;

@ApiModelProperty(required = false, hidden = true)
@Version
private String token;

@ApiModelProperty(required = false, hidden = true)
@Version
private boolean paymentStatus;

	public boolean isPaymentStatus() {
	return paymentStatus;
}

public void setPaymentStatus(boolean paymentStatus) {
	this.paymentStatus = paymentStatus;
}

	public String getToken() {
		return token;
	}

public void setToken(String token) {
	this.token = token;
}

public boolean isNewReg() {
	return newReg;
}

public void setNewReg(boolean newReg) {
	this.newReg = newReg;
}

private String mobNumber;

private String caregiverNumber;


public String getCaregiverNumber() {
	return caregiverNumber;
}

public void setCaregiverNumber(String caregiverNumber) {
	this.caregiverNumber = caregiverNumber;
}

public int getUserId() {
	return userId;
}

public void setUserId(int userId) {
	this.userId = userId;
}

public String getMobNumber() {
	return mobNumber;
}

public void setMobNumber(String mobNumber) {
	this.mobNumber = mobNumber;
}
}
